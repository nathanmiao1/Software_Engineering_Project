package menrva.control;

import menrva.DataManager;
import menrva.entities.Course;
import menrva.entities.UserAccount;
import java.util.List;

public class CreateAssignmentControl {
	private DataManager dm;
	
	public CreateAssignmentControl(DataManager dm) {
		this.dm = dm;
	}
	
	public boolean saveAssignment(String name, String courseId) {
		boolean result = dm.saveAssignment(name, courseId);
		return result;
	}
	
	public List<Course> getCourses() {
		UserAccount user = LoginControl.user;
		return dm.getCourses(user.getId(), user.getType());
	}
}
