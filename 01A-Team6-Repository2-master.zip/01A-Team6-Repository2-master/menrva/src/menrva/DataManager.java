package menrva;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.mysql.jdbc.PreparedStatement;

import menrva.entities.Assignment;
import menrva.entities.Course;
import menrva.entities.Assignment;
import menrva.entities.MenrvaFile;
import menrva.entities.Rubric;
import menrva.entities.UserAccount;
import menrva.entities.Grade;

public class DataManager {
	Connection connection = null;
	
	public DataManager() {
		 try {
		     Class.forName("com.mysql.jdbc.Driver").newInstance();
		 } catch (Exception e) {
			 System.err.println(e.toString());
		 }
		 
		 /**
		  * Getting "access denied" error when trying to run SQL create scripts on team database
		  * so we are using team leader's database instead
		  * 
		  * NOTE: tried my Login AND team login
		  */
		String url = "jdbc:mysql://cs2043.cs.unb.ca:3306/coneill4";
		try {
			connection = DriverManager.getConnection(url, "coneill4", "6QlKILO9");
		} catch (SQLException e) {
			System.err.println("Database connection error.");
		}
	}

	/**
	 * retrieve a <code>User Account</code> from the database given the <code>ID</code>,
	 * <code>password</code>, and account <code>type</code>
	 * @param id user ID
	 * @param password user password
	 * @param type user account type
	 * @return retrieved <code>User Account</code> if account exists, <code>null</code> otherwise
	 */
	public UserAccount getUserAccount(String id, String password, String type) {
		UserAccount account = null;
		try {
			Statement stmt = connection.createStatement();
			
			// create query string
			String sqlQuery = "select * from UserAccounts where Id = '" + id + "'";
			sqlQuery += " and Password = sha1('" + password + "')";
			sqlQuery += " and Type = '" + type + "';";
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// convert retrieved rows to UserAccount object
			while (rs.next()) {
				account = new UserAccount();
				account.setId(rs.getString("Id"));
				account.setType(rs.getString("Type"));
				account.setFirstName(rs.getString("FirstName"));
				account.setLastName(rs.getString("LastName"));
				account.setAddress(rs.getString("Address"));
				account.setContactInfo(rs.getString("ContactInfo"));
			}
		} catch (SQLException e) {
			System.err.println("SQL error: getUserAccount(id, password, type)");
			return account;
		}
		
		return account;
	}
	
	/**
	 * retrieve a <code>User Account</code> from the database given the <code>ID</code>
	 * and account <code>type</code>
	 * @param id user ID
	 * @param type user account type
	 * @return retrieved <code>User Account</code> if account exists, <code>null</code> otherwise
	 */
	public UserAccount getUserAccount(String id, String type) {
		UserAccount account = null;
		try {
			Statement stmt = connection.createStatement();
			
			// create query string
			String sqlQuery = "select * from UserAccounts where Id = '" + id + "' and Type = '" + type + "';";
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);

			// convert retrieved rows to UserAccount object
			while (rs.next()) {
				account = new UserAccount();
				account.setId(rs.getString("Id"));
				account.setType(rs.getString("Type"));
				account.setFirstName(rs.getString("FirstName"));
				account.setLastName(rs.getString("LastName"));
				account.setAddress(rs.getString("Address"));
				account.setContactInfo(rs.getString("ContactInfo"));
			}
		} catch (SQLException e) {
			System.err.println("SQL error: getUserAccount(id, type)");
			return account;
		}
		
		return account;
	}
	
	/**
	 * retrieves all the grades for the current student
	 * @param id user ID
	 * @return an array of grades
	 */
	public ArrayList<Grade> getGrades(UserAccount student) {
		ArrayList<Grade> grades = new ArrayList<Grade>();
		
		try {
			Statement stmt = connection.createStatement();
			
			// create query string
			String sqlQuery = "select * from Grades where StudentId = '" + student.getId() + "';";
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);

			
			// convert retrieved rows to Grade object array
			int count = 0;
			while (rs.next()) {
				Grade g = new Grade();
				int asID = rs.getInt("AssignmentId");
				g.setAssignment(getAsignment(asID));
				
				String courseID = rs.getString("CourseId");
				g.setCourse(getCourse(courseID));
				
				g.setStudent(student);
				g.setGrade(rs.getDouble("Grade"));
				grades.add(count, g);
				count++;
			}
		} catch (SQLException e) {
			System.err.println("SQL error: getGrades(id)");
			return grades;
		}
		
		return grades;
	}
	
	/**
	 * retrieve an assignment from the database given the <code>ID</code>
	 * @param id assignment ID
	 * @return as the assignment object
	 */
	public Assignment getAsignment(int id) {
		Assignment as = null;
		try {
			Statement stmt = connection.createStatement();
			
			// create query string
			String sqlQuery = "select * from Assignments where Id = " + id + ";";
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);

			// convert retrieved rows to Assignment object
			while (rs.next()) {
				as = new Assignment();
				as.setId(rs.getInt("Id"));
				as.setName(rs.getString("Name"));
				
				String courseId = rs.getString("CourseId");
				as.setCourse(getCourse(courseId));
			}
		} catch (SQLException e) {
			System.err.println("SQL error: getUserAccount(id)");
			return as;
		}
		
		return as;
	}
	
	/**
	 * retrieve a <code>User Account</code> from the database given the <code>ID</code>
	 * @param id user ID
	 * @return retrieved <code>User Account</code> if account exists, <code>null</code> otherwise
	 */
	public UserAccount getUserAccount(String id) {
		UserAccount account = null;
		try {
			Statement stmt = connection.createStatement();
			
			// create query string
			String sqlQuery = "select * from UserAccounts where Id = '" + id + "';";
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);

			// convert retrieved rows to UserAccount object
			while (rs.next()) {
				account = new UserAccount();
				account.setId(rs.getString("Id"));
				account.setType(rs.getString("Type"));
				account.setFirstName(rs.getString("FirstName"));
				account.setLastName(rs.getString("LastName"));
				account.setAddress(rs.getString("Address"));
				account.setContactInfo(rs.getString("ContactInfo"));
			}
		} catch (SQLException e) {
			System.err.println("SQL error: getUserAccount(id)");
			return account;
		}
		
		return account;
	}
	
	/**
	 * save a <code>File</code> to the database
	 * @param file file to save
	 * @param fileName name of file to be saved
	 * @return <code>true</code> if save successful, <code>false</code> otherwise
	 */
	public boolean saveLockerFile(File file, String name, String studentId) {
		try {
			//create query string
			String sqlQuery = "insert into Files (Name, File) values('" + name + "', ?);";
			PreparedStatement pstmt = (PreparedStatement) connection.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS);

			// prepare file data
			FileInputStream inputStream = new FileInputStream(file);
			pstmt.setBinaryStream(1, inputStream, (int)file.length());
			
			// execute query
			pstmt.executeUpdate();
			ResultSet rs = pstmt.getGeneratedKeys();
			rs.next();
			int fileId = rs.getInt(1); // get auto-generated file id
			
			sqlQuery = "insert into Lockers values('" + studentId + "', " + fileId + ");";
			connection.createStatement().execute(sqlQuery);

			return true;
		} catch (Exception e) {
			System.out.println("SQL error: saveLockerFile");
			return false;
		}
	}
	
	/**
	 * Save an assignment file to the database.
	 * @param file file to save
	 * @param id assignment ID
	 * @return <code>true</code> if save successful, <code>false</code> otherwise
	 */
	public boolean saveAssignmentFile(File file, Integer assignmentId) {
		try {
			//create query string
			String sqlQuery = "insert into Files (File) values(?);";
			PreparedStatement pstmt = (PreparedStatement) connection.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS);

			// prepare file data
			FileInputStream inputStream = new FileInputStream(file);
			pstmt.setBinaryStream(1, inputStream, (int)file.length());
			
			// execute query
			pstmt.executeUpdate();
			ResultSet rs = pstmt.getGeneratedKeys();
			rs.next();
			int fileId = rs.getInt(1); // get auto-generated file id
			
			sqlQuery = "insert into AssignmentFileLinks values(" + fileId + ", " + assignmentId + ", 'Submission');";
			connection.createStatement().execute(sqlQuery);

			return true;
		} catch (Exception e) {
			System.out.println("SQL error: saveAssignmentFile");
			return false;
		}
	}
	
	/**
	 * retrieve a File from the database given the file <code>id</code>
	 * @param id the file id
	 * @param pathname absolute path of the retrieved file
	 * @return  the retrieved file, <code>null</code> if the file does not exist
	 */
	public File retrieveFile(int id) {
		File file = null;
		
		try {
			Statement stmt = connection.createStatement();
			String sqlQuery = "select * from Files where Id = " + id + ";";
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			while (rs.next()) {
				String home = System.getProperty("user.home");
				file = new File(home + "/Downloads/" + rs.getString("Name"));
				FileOutputStream out = new FileOutputStream(file);
				InputStream input = rs.getBinaryStream("File");
				byte[] buffer = new byte[1024];
				while (input.read(buffer) > 0) {
					out.write(buffer);
				}
				out.close();
			}
		} catch (Exception e) {
			System.out.println("SQL error: retrieveFile");
			return file;
		}
		return file;
	}
	
	/**
	 * save a <code>User Account</code> to the database
	 * @param form a <code>Map</code> of &ltdatabase-column-name&gt&ltvalue&gt pairs
	 * @return <code>true</code> if save successful, <code>false</code> otherwise
	 */
	public boolean saveAccount(Map<String, String> form) {
		try {
			//create query string
			StringBuilder columns = new StringBuilder();
			StringBuilder values = new StringBuilder();
			
			// insert required fields
			columns.append("insert into UserAccounts (Id, Password");
			values.append("values('" + form.remove("Id") + "', sha1('" + form.remove("Password") + "')");
			
			// append optional fields
			for (Entry<String, String> entry : form.entrySet()) {
				columns.append(", " + entry.getKey());
				values.append(", '" + entry.getValue() + "'");
			}
			columns.append(") ");
			values.append(");");

			Statement stmt = connection.createStatement();
			stmt.execute(columns.toString() + values.toString());
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: saveAccount");
			return false;
		}
	}
	
	/**
	 * update an existing <code>User Account</code> in the database
	 * @param form a <code>Map</code> of &ltdatabase-column-name&gt&ltvalue&gt pairs
	 * @return <code>true</code> if update successful, <code>false</code> otherwise
	 */
	public boolean updateAccount(Map<String, String> form) {
		try {
			//create query string
			String queryString = "";
			String id = form.remove("Id");

			queryString += "update UserAccounts set ";
			
			String password = form.remove("Password");
			if (password != null) {
				queryString += "Password = sha1('" + password + "'), " ;
			}
			
			// append updated fields
			for (Entry<String, String> entry : form.entrySet()) {
				queryString += entry.getKey() + " = '" + entry.getValue() + "',";
			}
			int index = queryString.lastIndexOf(",");
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append(queryString.substring(0, index));
			sqlQuery.append(" where Id = '" + id + "';");
			
			Statement stmt = connection.createStatement();
			stmt.execute(sqlQuery.toString().trim());
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: updateAccount");
			return false;
		}
	}
	
	/**
	 * Permanently remove a <code>User Account</code> from the database.
	 * @param id account ID
	 * @return <code>true</code> if delete successful, <code>false</code> otherwise
	 */
	public boolean deleteAccount(String id) {
		try {
			Statement stmt = connection.createStatement();
			stmt.execute("delete from UserAccounts where Id = '" + id + "';"); 
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: deleteAccount");
			return false;
		}
	}
	
	/**
	 * retrieve all <code>User Account</code>s from the database of type 'Professor'
	 * @return a <code>List</code> of retrieved <code>User Account</code>s
	 */
	public List<UserAccount> getProfs() {
		List<UserAccount> profs = new ArrayList<>();
		try {
			// create query string
			String sqlQuery = "select * from UserAccounts where Type = 'Professor';";
			Statement stmt = connection.createStatement();
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// convert retrieved rows to UserAccount object
			while (rs.next()) {
				UserAccount account = new UserAccount();
				account.setId(rs.getString("Id"));
				account.setType(rs.getString("Type"));
				account.setFirstName(rs.getString("FirstName"));
				account.setLastName(rs.getString("LastName"));
				account.setAddress(rs.getString("Address"));
				account.setContactInfo(rs.getString("ContactInfo"));
				profs.add(account);
			}
		} catch (Exception e) {
			System.out.println("SQL error: getAllProfs");
			return profs;
		}
		return profs;
	}
	
	/**
	 * retrieve all <code>User Account</code>s from the database of type 'Teaching Assistant'
	 * @return a <code>List</code> of retrieved <code>User Account</code>s
	 */
	public List<UserAccount> getTAs() {
		List<UserAccount> tas = new ArrayList<>();
		try {
			// create query string
			String sqlQuery = "select * from UserAccounts where Type = 'Teaching Assistant';";
			Statement stmt = connection.createStatement();
			
			// execute SQL query
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// convert retrieved rows to UserAccount object
			while (rs.next()) {
				UserAccount account = new UserAccount();
				account.setId(rs.getString("Id"));
				account.setType(rs.getString("Type"));
				account.setFirstName(rs.getString("FirstName"));
				account.setLastName(rs.getString("LastName"));
				account.setAddress(rs.getString("Address"));
				account.setContactInfo(rs.getString("ContactInfo"));
				tas.add(account);
			}
		} catch (Exception e) {
			System.out.println("SQL error: getAllTAs");
			return tas;
		}
		return tas;
	}
	
	/**
	 * save a <code>Course</code> to the database
	 * @param form a <code>Map</code> of &ltdatabase-column-name&gt&ltvalue&gt pairs
	 * @return <code>true</code> if save successful, <code>false</code> otherwise
	 */
	public boolean saveCourse(Map<String, Object> form) {
		try {
			//create query string
			StringBuilder columns = new StringBuilder();
			StringBuilder values = new StringBuilder();
			List<String> profs = (List<String>) form.remove("Professors");
			List<String> tas = (List<String>) form.remove("Teaching Assistants");
			String courseId = form.remove("Id").toString();
			
			// insert required fields
			columns.append("insert into Courses (Id");
			values.append("values ('" + courseId + "'");
			
			// append optional fields
			for (Entry<String, Object> entry : form.entrySet()) {
				columns.append(", " + entry.getKey());
				values.append(", '" + entry.getValue() + "'");
			}
			columns.append(") ");
			values.append(");");

			Statement stmt = connection.createStatement();
			stmt.execute(columns.toString() + values.toString());
			
			// create ProfCourse object
			for (String id : profs) {
				String query = "insert into UserCourseLinks values (";
				query += "'" + id + "', '" + courseId + "', 'Professor');";
				stmt.execute(query);
			}
			
			// create TACourse object
			for (String id : tas) {
				String query = "insert into UserCourseLinks values (";
				query += "'" + id + "', '" + courseId + "', 'Teaching Assistant');";
				stmt.execute(query);
			}
			
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: saveCourse");
			return false;
		}
	}
	
	/**
	 * update an existing <code>Course</code> in the database
	 * @param form a <code>Map</code> of &ltdatabase-column-name&gt&ltvalue&gt pairs
	 * @return <code>true</code> if update successful, <code>false</code> otherwise
	 */
	public boolean updateCourse(Map<String, Object> form) {
		try {
			//create query string
			String queryString = "";
			String courseId = form.remove("Id").toString();
			List<String> profs = (List<String>) form.remove("Professors");
			List<String> tas = (List<String>) form.remove("Teaching Assistants");
			
			queryString += "update Courses set ";
			
			// append updated fields
			for (Entry<String, Object> entry : form.entrySet()) {
				queryString += entry.getKey() + " = '" + entry.getValue().toString() + "',";
			}
			
			Statement stmt = connection.createStatement();
			if (!queryString.equals("update Courses set ")) {
				int index = queryString.lastIndexOf(",");
				StringBuilder sqlQuery = new StringBuilder();
				sqlQuery.append(queryString.substring(0, index));
				sqlQuery.append(" where Id = '" + courseId + "';");
				stmt.execute(sqlQuery.toString().trim());
			}
			
			// update user-course links
			stmt.execute("delete from UserCourseLinks where CourseId = '" + courseId + "';"); // delete existing links
			
			// create ProfCourse object
			for (String id : profs) {
				String query = "insert into UserCourseLinks values (";
				query += "'" + id + "', '" + courseId + "', 'Professor');";
				stmt.execute(query);
			}
			
			// create TACourse object
			for (String id : tas) {
				String query = "insert into UserCourseLinks values (";
				query += "'" + id + "', '" + courseId + "', 'Teaching Assistant');";
				stmt.execute(query);
			}
			
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: updateCourse");
			return false;
		}
	}
	
	/**
	 * Permanently remove a <code>Course</code> from the database.
	 * @param id course ID
	 * @return <code>true</code> if delete successful, <code>false</code> otherwise
	 */
	public boolean deleteCourse(String id) {
		try {
			Statement stmt = connection.createStatement();
			stmt.execute("delete from Courses where Id = '" + id + "';"); 
			stmt.execute("delete from UserCourseLinks where CourseId = '" + id + "';"); // delete existing links
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: deleteCourse");
			return false;
		}
	}
	
	/**
	 * Permanently remove a <code>Course</code> from the database.
	 * @param id course ID
	 * @return <code>true</code> if delete successful, <code>false</code> otherwise
	 */
	public boolean removeLockerFile(int id) {
		try {
			Statement stmt = connection.createStatement();
			stmt.execute("delete from Lockers where FileId = " + id + ";"); 
			stmt.execute("delete from Files where Id = " + id + ";"); // delete existing links
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: deleteLockerFile");
			return false;
		}
	}
	
	/**
	 * Retrieve all <code>Course</code>s from the database.
	 * @return a <code>List</code> of retrieved <code>Course</code>s
	 */
	public List<Course> getAllCourses() {
		List<Course> courses = new ArrayList<>();
		try {
			String sqlQuery = "select * from Courses;";

			// execute SQL course query
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// convert retrieved rows to Course object
			while (rs.next()) {
				Course course = new Course();
				String id = rs.getString("Id");
						
				course.setId(id);
				course.setName(rs.getString("Name"));
				course.setLocation(rs.getString("Location"));
				course.setDescription(rs.getString("Description"));
				
				// fetch Professor and TA objects
				String query = "select * from UserCourseLinks where CourseId = '" + id + "' and Type = 'Professor';";
				ResultSet profSet = connection.createStatement().executeQuery(query);
				while (profSet.next()) {
					String profId = profSet.getString("UserId");
					UserAccount prof = getUserAccount(profId, "Professor");
					if (prof != null) {
						course.addProf(prof);
					}
				}
				
				query = "select * from UserCourseLinks where CourseId = '" + id + "' and Type = 'Teaching Assistant';";
				ResultSet taSet = connection.createStatement().executeQuery(query);
				while (taSet.next()) {
					String taId = taSet.getString("UserId");
					UserAccount ta = getUserAccount(taId, "Teaching Assistant");
					if (ta != null) {
						course.addTA(ta);
					}
				}
				
				courses.add(course);
			}
		} catch (Exception e) {
			System.out.println("SQL error: getAllCourses");
			return courses;
		}
		return courses;
	}
	
	/**
	 * retrieve a <code>Course</code> from the database given the <code>ID</code>.
	 * @param id course ID
	 * @return retrieved <code>Course</code> if course exists, <code>null</code> otherwise
	 */
	public Course getCourse(String id) {
		Course course = null;
		try {
			String sqlQuery = "select * from Courses where Id = '" + id + "';";

			// execute SQL course query
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// convert retrieved rows to Course object
			while (rs.next()) {
				course = new Course();
				course.setId(rs.getString("Id"));
				course.setName(rs.getString("Name"));
				course.setLocation(rs.getString("Location"));
				
				// fetch Professor and TA objects
				String query = "select * from UserCourseLinks where CourseId = '" + id + "' and Type = 'Professor';";
				ResultSet profSet = connection.createStatement().executeQuery(query);
				while (profSet.next()) {
					String profId = profSet.getString("UserId");
					UserAccount prof = getUserAccount(profId, "Professor");
					if (prof != null) {
						course.addProf(prof);
					}
				}
				profSet.close();
				
				query = "select * from UserCourseLinks where CourseId = '" + id + "' and Type = 'Teaching Assistant';";
				ResultSet taSet = connection.createStatement().executeQuery(query);
				while (taSet.next()) {
					String taId = taSet.getString("UserId");
					UserAccount ta = getUserAccount(taId, "Teaching Assistant");
					if (ta != null) {
						course.addProf(ta);
					}
				}
				taSet.close();
			}
		} catch (Exception e) {
			System.out.println("SQL error: getCourse");
			return course;
		}
		return course;
	}
	
	/**
	 * Retrieve all students registered for a given <code>Course</code>.
	 * @param id course ID
	 * @return a <code>List</code> of retrieved student <code>UserAccount</code>s
	 */
	public List<UserAccount> getRegistrations(String id) {
		List<UserAccount> students = new ArrayList<>();
		try {
			// create query
			String sqlQuery = "select * from UserCourseLinks where CourseId = '" + id + "' and Type = 'Student';";
			Statement stmt = connection.createStatement();
			
			// execute query
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// parse data
			while (rs.next()) {
				UserAccount student = new UserAccount();
				student = getUserAccount(rs.getString("UserId"));
				students.add(student);
			}
		} catch (Exception e) {
			System.out.println("SQL error: getRegistrations");
			return students;
		}
		return students;
	}
	
	/**
	 * Register a given student for a given <code>Course</code>.
	 * @param studentId student ID
	 * @param courseId course ID
	 * @return <code>true</code> if save successful, <code>false</code> otherwise
	 */
	public boolean saveRegistration(String studentId, String courseId) {
		try {
			StringBuilder sqlQuery = new StringBuilder("insert into UserCourseLinks values (");
			sqlQuery.append("'" + studentId + "',");
			sqlQuery.append("'" + courseId + "',");
			sqlQuery.append("'Student');");
			
			connection.createStatement().execute(sqlQuery.toString().trim());
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: saveRegistration");
			return false;
		}
	}
	
	/**
	 * Permanently unregister a given student from a given <code>Course</code>.
	 * @param studentId student ID
	 * @param courseId course ID
	 * @return <code>true</code> if delete successful, <code>false</code> otherwise
	 */
	public boolean deleteRegistration(String studentId, String courseId) {
		try {
			StringBuilder sqlQuery = new StringBuilder("delete from UserCourseLinks where ");
			sqlQuery.append("UserId = '" + studentId + "' and ");
			sqlQuery.append("CourseId = '" + courseId + "';");
			
			connection.createStatement().execute(sqlQuery.toString().trim());
			return true;
		} catch (Exception e) {
			System.out.println("SQL error: deleteRegistration");
			return false;
		}
	}
	
	/**
	 * Set a grade with associated course assignment.
	 * @param studId student ID
	 * @param assgId assignment ID
	 * @param grade grade received
	 * @param courseId course ID
	 * @return 1 if fail and 0 if success
	 */
	public int setGrade(String studId, String assgId, double grade, String courseId, int weight) {
		int success = 1;
		try {
			//create query string
			PreparedStatement pstmt = null;
			String sqlQuery = "REPLACE INTO Grades (AssignmentId, CourseId, StudentId, Grade, Weight) " + "VALUES( ?, ?, ?, ?, ?);";
			pstmt = (PreparedStatement) connection.prepareStatement(sqlQuery);
			pstmt.setString(1,  assgId);
			pstmt.setString(2,  courseId);
			pstmt.setString(3,  studId);
			pstmt.setDouble(4,  grade);
			pstmt.setInt(5, weight);
			pstmt.execute();
			success = 0;
		} catch (Exception e) {
			System.out.println("SQL error: grade not set");
			return success;
		}
		return success;
	}
	
	/**
	 * Retrieve all courses matching a given user and link type.
	 * @param id user ID
	 * @param type link type ('Student', 'Professor', 'Teaching Assistant', 'Administrator')
	 * @return a <code>List</code> of all retrieved <code>Course</code>s
	 */
	public List<Course> getCourses(String id, String type) {
		List<Course> courses = new ArrayList<>();
		try {
			String sqlQuery = "select * from UserCourseLinks where UserId = '" + id + "' and Type = '" + type + "';";
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			// convert retrieved rows to Course object
			while (rs.next()) {
				courses.add(getCourse(rs.getString("CourseId")));
			}
		} catch (Exception e) {
			System.out.println("SQL error: getCourses");
			return courses;
		}
		return courses;
	}
	
	/**
	 * Create a new assignment for a course.
	 * @param name The name of the assignment
	 * @param course The course ID of the assignment
	 * @return <code>true</code> if the assignment was successfully created, <code>false</code> otherwise
	 */
	public boolean saveAssignment(String name, String course) {
		try {
			Statement stmt = connection.createStatement();
			String sqlQuery = "insert into Assignments(CourseId, Name) values (";
			sqlQuery += "'" + course + "', '" + name + "');";
			stmt.execute(sqlQuery);
			return true;
		} catch (Exception e) {
			System.err.println("SQL error: saveAssignment");
			return false;
		}
	}
	
	/**
	 * Retrieve all assignments for a given course.
	 * @param courseId course ID
	 * @return a <code>List</code> of all retrieved <code>Assignment</code>s
	 */
	public List<Assignment> getAssignments(String courseId) {
		List<Assignment> assignments = new ArrayList<>();
		try {
			String sqlQuery = "select * from Assignments where CourseId = '" + courseId + "';";
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			while (rs.next()) {
				Assignment assignment = new Assignment();
				assignment.setCourse(getCourse(courseId));
				assignment.setId(rs.getInt("Id"));
				assignment.setName(rs.getString("Name"));
				assignments.add(assignment);
			}
		} catch (Exception e) {
			System.out.println("SQL error: getAssignments");
		}
		return assignments;
	}
	
	/**
	 * Retrieve all <code>File</code> for an assignment matching the given assignment ID and type.
	 * @param assignmentId assignment ID
	 * @param type link type ('Submission', 'Description', 'Rubric')
	 * @return a <code>List</code> of all retrieved <code>File</code>s
	 */
	public List<MenrvaFile> getAssignmentFiles(Integer id, String type) {
		List<MenrvaFile> files = new ArrayList<>();
		try {
			String sqlQuery = "select * from AssignmentFileLinks where AssignmentId = " + id + ";";
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			while (rs.next()) {
				int fileId = rs.getInt("FileId");
				File file = retrieveFile(fileId);
				MenrvaFile mfile = new MenrvaFile(file.getAbsolutePath());
				mfile.setId(fileId);
				files.add(mfile);
			}
		} catch(Exception e) {
			System.out.println("SQL error: getAssignmentFiles");
			return files;
		}
		return files;
	}
	
	/**
	 * Retrieve a list of files stored in a given student's locker
	 * @param studentId student ID
	 * @return a list of retrieved files
	 */
	public List<MenrvaFile> getLockerFiles(String studentId) {
		List<MenrvaFile> files = new ArrayList<>();
		try {
			String sqlQuery = "select * from Lockers where StudentId = '" + studentId + "';";
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			
			while (rs.next()) {
				int fileId = rs.getInt("FileId");
				File file = retrieveFile(fileId);
				MenrvaFile mfile = new MenrvaFile(file.getAbsolutePath());
				mfile.setId(fileId);
				files.add(mfile);
			}
		} catch(Exception e) {
			System.out.println("SQL error: getLockerFiles");
			return files;
		}
		return files;
  }
  
  /**
	 * Retrieve all <code>Rubric</code>s for a given course.
	 * @param courseId course ID
	 * @return all retrieved <code>Rubric</code>s
	 */
	public List<Rubric> getRubrics(String courseId) {
		List<Rubric> rubrics = new ArrayList<>();
		Course course = getCourse(courseId);
		try {
			String sqlQuery = "select * from Rubrics where CourseId = '" + courseId + "';";
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);

			while (rs.next()) {
				Rubric rubric = new Rubric();
				rubric.setCourse(course);
				File file = retrieveFile(rs.getInt("FileId"));
				rubric.setFile(new MenrvaFile(file.getAbsolutePath()));
				rubrics.add(rubric);
			}
		} catch (Exception e) {
			System.out.println("SQL error: getRubrics");
		}
		return rubrics;
	}
	
	/**
	 * Store a <code>Rubric</code> in the database.
	 * @param file rubric file
	 * @param courseId course ID
	 * @return <code>true</code> if save successful, <code>false</code> otherwise
	 */
	public boolean saveRubric(File file, String courseId) {
		boolean success = false;
		
		try {
			//create query string
			String sqlQuery = "insert into Files (Name, File) values('" + file.getName() + "', ?);";
			PreparedStatement pstmt = (PreparedStatement) connection.prepareStatement(sqlQuery);

			// prepare file data
			FileInputStream inputStream = new FileInputStream(file);
			pstmt.setBinaryStream(1, inputStream, (int)file.length());
			
			// execute query
			pstmt.execute();
			ResultSet rs = pstmt.getGeneratedKeys();
			rs.next();
			int fileId = rs.getInt(1); // get auto-generated file id
			
			sqlQuery = "insert into Rubrics values(" + fileId + ", '" + courseId + "');";
			connection.createStatement().execute(sqlQuery);
			
			success = true;
		} catch (Exception e) {
			System.out.println("SQL error: saveRubric");
			return success;
		}
		return success;
	}
}
