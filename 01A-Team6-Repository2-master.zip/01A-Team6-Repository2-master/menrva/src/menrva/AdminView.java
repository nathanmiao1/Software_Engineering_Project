package menrva;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridBagLayout;
import javax.swing.JLabel;

import menrva.ui.CreateClassListUI;
import menrva.ui.CreateCourseUI;
import menrva.ui.CreateUserAccountUI;
import menrva.ui.LoginUI;
import menrva.ui.UploadAssignmentFileUI;

import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class AdminView {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminView window = new AdminView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblWelcome = new JLabel("Welcome, Administrator!");
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_lblWelcome = new GridBagConstraints();
		gbc_lblWelcome.gridwidth = 6;
		gbc_lblWelcome.insets = new Insets(0, 0, 5, 5);
		gbc_lblWelcome.gridx = 1;
		gbc_lblWelcome.gridy = 1;
		frame.getContentPane().add(lblWelcome, gbc_lblWelcome);
		
		JButton btnCreateUser = new JButton("Manage Accounts");
		btnCreateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   CreateUserAccountUI.openWindow();
				   frame.setVisible(false);
				   frame.dispose();
			}
		});
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnLogOut = new GridBagConstraints();
		gbc_btnLogOut.insets = new Insets(0, 0, 5, 0);
		gbc_btnLogOut.gridx = 7;
		gbc_btnLogOut.gridy = 1;
		frame.getContentPane().add(btnLogOut, gbc_btnLogOut);
		GridBagConstraints gbc_btnCreateUser = new GridBagConstraints();
		gbc_btnCreateUser.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnCreateUser.insets = new Insets(0, 0, 5, 5);
		gbc_btnCreateUser.gridx = 1;
		gbc_btnCreateUser.gridy = 2;
		frame.getContentPane().add(btnCreateUser, gbc_btnCreateUser);
		
		JButton btnCreateCourse = new JButton("Manage Courses");
		btnCreateCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateCourseUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnCreateCourse = new GridBagConstraints();
		gbc_btnCreateCourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnCreateCourse.insets = new Insets(0, 0, 5, 5);
		gbc_btnCreateCourse.gridx = 1;
		gbc_btnCreateCourse.gridy = 3;
		frame.getContentPane().add(btnCreateCourse, gbc_btnCreateCourse);
		
		JButton btnManageCourseRegistration = new JButton("Manage Course Registration");
		btnManageCourseRegistration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateClassListUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnManageCourseRegistration = new GridBagConstraints();
		gbc_btnManageCourseRegistration.insets = new Insets(0, 0, 0, 5);
		gbc_btnManageCourseRegistration.gridx = 1;
		gbc_btnManageCourseRegistration.gridy = 4;
		frame.getContentPane().add(btnManageCourseRegistration, gbc_btnManageCourseRegistration);
	}

}
