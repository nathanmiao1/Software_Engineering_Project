package menrva.control;

import java.io.File;
import java.util.List;

import menrva.DataManager;
import menrva.entities.Assignment;
import menrva.entities.Course;
import menrva.entities.Rubric;

public class UploadRubricControl {
	DataManager dm;

	public UploadRubricControl(DataManager dm) {
		this.dm = dm;
	}

	public boolean saveFile(File file, String courseId) {
		return dm.saveRubric(file, courseId);
	}
	
	public List<Course> getCourses() {
		return dm.getCourses(LoginControl.user.getId(), "Professor");
	}

	public List<Rubric> getRubrics(String courseId) {
		return dm.getRubrics(courseId);
	}
}