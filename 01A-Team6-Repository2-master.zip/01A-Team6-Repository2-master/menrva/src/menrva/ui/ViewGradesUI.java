package menrva.ui;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import menrva.DataManager;
import menrva.ProfView;
import menrva.StudentView;
import menrva.TAView;
import menrva.control.LoginControl;
import menrva.control.ViewGradesControl;
import menrva.entities.Grade;
import javax.swing.JTextPane;

public class ViewGradesUI {

	private JFrame frame;
	private StringBuilder assignments;
	private StringBuilder grades;
	
	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewGradesUI window = new ViewGradesUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ViewGradesUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		assignments = new StringBuilder();
		grades = new StringBuilder();
		
		DataManager dm = new DataManager();
		ViewGradesControl control = new ViewGradesControl(dm);
		
		for(Grade grade : control.processViewGrades(LoginControl.user)) {
			grades.append(grade.getGrade());
			grades.append("\n");
			assignments.append(grade.getAssignment());
			assignments.append("\n");
		}
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{87, 183, 186, 0};
		gridBagLayout.rowHeights = new int[]{55, 149, 0, 0};
		gridBagLayout.columnWeights = new double[]{1.0, 1.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, 1.0, 1.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   switch(LoginControl.user.getType()) {
				   	case "Student":
				   		StudentView.openWindow();
				   		break;
				   	case "Professor":
				   		ProfView.openWindow();
				   		break;
				   	case "Teaching Assistant":
				   		TAView.openWindow();
				   }
				   frame.setVisible(false);
					frame.dispose();
			}
		});
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 5, 5);
		gbc_btnBack.gridx = 0;
		gbc_btnBack.gridy = 0;
		frame.getContentPane().add(btnBack, gbc_btnBack);
		
		JLabel lblAssignment = new JLabel("Assignment");
		GridBagConstraints gbc_lblAssignment = new GridBagConstraints();
		gbc_lblAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_lblAssignment.gridx = 1;
		gbc_lblAssignment.gridy = 0;
		frame.getContentPane().add(lblAssignment, gbc_lblAssignment);
		
		JLabel lblGrade = new JLabel("Grade");
		GridBagConstraints gbc_lblGrade = new GridBagConstraints();
		gbc_lblGrade.insets = new Insets(0, 0, 5, 0);
		gbc_lblGrade.gridx = 2;
		gbc_lblGrade.gridy = 0;
		frame.getContentPane().add(lblGrade, gbc_lblGrade);
		
		JTextPane txtpnAssignments = new JTextPane();
		txtpnAssignments.setEditable(false);
		GridBagConstraints gbc_txtpnAssignments = new GridBagConstraints();
		gbc_txtpnAssignments.insets = new Insets(0, 0, 5, 5);
		gbc_txtpnAssignments.fill = GridBagConstraints.BOTH;
		gbc_txtpnAssignments.gridx = 1;
		gbc_txtpnAssignments.gridy = 1;
		frame.getContentPane().add(txtpnAssignments, gbc_txtpnAssignments);
		txtpnAssignments.setText(assignments.toString());
		
		JTextPane txtpnGrades = new JTextPane();
		txtpnGrades.setEditable(false);
		GridBagConstraints gbc_txtpnGrades = new GridBagConstraints();
		gbc_txtpnGrades.insets = new Insets(0, 0, 5, 0);
		gbc_txtpnGrades.fill = GridBagConstraints.BOTH;
		gbc_txtpnGrades.gridx = 2;
		gbc_txtpnGrades.gridy = 1;
		frame.getContentPane().add(txtpnGrades, gbc_txtpnGrades);
		txtpnGrades.setText(grades.toString());
	}
}
