package menrva.control;
import java.util.ArrayList;
import java.util.List;

import menrva.DataManager;
import menrva.entities.Assignment;
import menrva.entities.Course;
import menrva.entities.UserAccount;
//import menrva.entities.Course;
public class GradesControl {
	
	private DataManager dm;
	private String optionPaneMessage;
	public GradesControl(DataManager d) {
		this.dm = d;
	}
	
	/**
	 * Insert a student grade to table for course.
	 * @param studId user ID
	 * @param assgID assignment ID
	 * @param grade grade
	 * @param courseId course ID
	 * @return 0 if grade is set, 1 if grade is not set,
	 */
	public int insertGrade(String studId, String assgId, double grade, String courseId, int weight) {
		//check student exists in course
		boolean studInCourse = checkStudentRegistration(courseId, studId);
		if(studInCourse == false) {
			setMessage("Student not in Course");
			return 1;
		}
		//try to add to database
		int success = dm.setGrade(studId,assgId,grade,courseId, weight);
		if(success == 1) {
			setMessage("Could not be added to database");
		}else
			setMessage("Success");
		return success;	
	}		
	/**
	 * gets set grade message on set grade UI try
	 * @return
	 */
	public String getMessage() {
		return optionPaneMessage;
	}
	/**
	 * Sets a message for display to submit button on grade entry try
	 * @param message
	 */
	public void setMessage(String message) {
		optionPaneMessage = message;
	}
	
	/**
	 * Checks student is in course.
	 * @param courseId course
	 * @param studId user ID
	 * @return false if student not in set, true if else
	 */
	public boolean checkStudentRegistration(String courseId, String studId) {
		List<UserAccount> students = new ArrayList<>();
		students = dm.getRegistrations(courseId);
		
		for(int i = 0; i < students.size(); i++) {
			UserAccount current = students.get(i);
			String id = current.getId();
			if(id.equals(studId))
				return true;
		}
		
		return false;
	}
	
	public List<Assignment> getAssignments(String courseId) {
		return dm.getAssignments(courseId);
	}
	
	public List<Course> getCourses() {
		UserAccount user = LoginControl.user;
		return dm.getCourses(user.getId(), user.getType());
	}
}


