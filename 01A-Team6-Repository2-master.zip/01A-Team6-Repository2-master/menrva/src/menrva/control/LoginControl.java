package menrva.control;

import menrva.DataManager;
import menrva.entities.UserAccount;

public class LoginControl {
	public static UserAccount user; // TODO: is this really bad?
	private DataManager dm;

	public LoginControl(DataManager dm) {
		this.dm = dm;
		user = null;
	}
	
	public boolean verifyLogin(String login, String password, String type) {
		boolean status = false;
		
		user = dm.getUserAccount(login, password, type);
		if (user != null) {
			status = true;
			user.setType(type); // TODO: make this a table column
		}
		
		return status;
	}
}
