package menrva.control;

import java.util.List;
import java.util.Map;

import menrva.DataManager;
import menrva.entities.UserAccount;

public class CreateCourseControl {
	private DataManager dm;
	
	public CreateCourseControl(DataManager dm) {
		this.dm = dm;
	}
	
	public List<UserAccount> getProfs() {
		return dm.getProfs();
	}
	
	public List<UserAccount> getTAs() {
		return dm.getTAs();
	}
	
	public boolean saveCourse(Map<String, Object> form) {
		return dm.saveCourse(form);
	}
	
	public boolean udpateCourse(Map<String, Object> form) {
		return dm.updateCourse(form);
	}
	
	public boolean deleteCourse(String id) {
		return dm.deleteCourse(id);
	}
	
	public boolean verifyCourse(String id) {
		return dm.getCourse(id) != null? true : false;
	}
}
