package menrva.entities;

public class Assignment {
	private int id;
	private String name;
	private Course course;
	
	public Assignment() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public double getPercentView(int weight, double grade) {
		return (double)(grade/weight);
	}
	
	public String toString() {
		if (this.name == null || this.course == null) {
			return Integer.toString(this.getId());
		}
		return this.getCourse().getName() + " : " + this.getName();
	}

	public String getGradeView(int weight, double grade) {
		return grade + "/" + weight;
	}
	
}
