package menrva.control;

import java.util.List;

import menrva.DataManager;
import menrva.entities.Grade;
import menrva.entities.UserAccount;

public class ViewGradesControl {
	private DataManager dm;
	
	public ViewGradesControl(DataManager dm) {
		this.dm = dm;
	}
	
	public List<Grade> processViewGrades(UserAccount student) {
		return dm.getGrades(student);
	}
}
