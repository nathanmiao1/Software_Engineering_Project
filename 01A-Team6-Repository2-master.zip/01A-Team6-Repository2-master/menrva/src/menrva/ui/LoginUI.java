package menrva.ui;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.JTextField;

import menrva.AdminView;
import menrva.DataManager;
import menrva.ProfView;
import menrva.StudentView;
import menrva.TAView;
import menrva.control.LoginControl;
import menrva.util.*;

public class LoginUI {

	private JFrame frame;
	private JTextField txtLogin;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI window = new LoginUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI window = new LoginUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblMenrvaLogin = new JLabel("MENRVA Login");
		GridBagConstraints gbc_lblMenrvaLogin = new GridBagConstraints();
		gbc_lblMenrvaLogin.insets = new Insets(0, 0, 5, 5);
		gbc_lblMenrvaLogin.gridx = 1;
		gbc_lblMenrvaLogin.gridy = 1;
		frame.getContentPane().add(lblMenrvaLogin, gbc_lblMenrvaLogin);
		
		JLabel lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.gridwidth = 8;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
		gbc_lblStatus.gridx = 1;
		gbc_lblStatus.gridy = 2;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		
		JLabel lblLogin = new JLabel("Login");
		GridBagConstraints gbc_lblLogin = new GridBagConstraints();
		gbc_lblLogin.anchor = GridBagConstraints.WEST;
		gbc_lblLogin.insets = new Insets(0, 0, 5, 5);
		gbc_lblLogin.gridx = 1;
		gbc_lblLogin.gridy = 3;
		frame.getContentPane().add(lblLogin, gbc_lblLogin);
		
		txtLogin = new JTextField();
		GridBagConstraints gbc_txtLogin = new GridBagConstraints();
		gbc_txtLogin.gridwidth = 3;
		gbc_txtLogin.insets = new Insets(0, 0, 5, 5);
		gbc_txtLogin.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLogin.gridx = 1;
		gbc_txtLogin.gridy = 4;
		frame.getContentPane().add(txtLogin, gbc_txtLogin);
		txtLogin.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.anchor = GridBagConstraints.WEST;
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 1;
		gbc_lblPassword.gridy = 5;
		frame.getContentPane().add(lblPassword, gbc_lblPassword);

		txtPassword = new JPasswordField();
		GridBagConstraints gbc_txtPassword = new GridBagConstraints();
		gbc_txtPassword.gridwidth = 3;
		gbc_txtPassword.insets = new Insets(0, 0, 5, 5);
		gbc_txtPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtPassword.gridx = 1;
		gbc_txtPassword.gridy = 6;
		frame.getContentPane().add(txtPassword, gbc_txtPassword);
		
		JLabel lblRole = new JLabel("Role");
		GridBagConstraints gbc_lblRole = new GridBagConstraints();
		gbc_lblRole.anchor = GridBagConstraints.WEST;
		gbc_lblRole.insets = new Insets(0, 0, 5, 5);
		gbc_lblRole.gridx = 1;
		gbc_lblRole.gridy = 7;
		frame.getContentPane().add(lblRole, gbc_lblRole);
		
		JSpinner spinner = new JSpinner(new CyclingSpinnerListModel(new String[] {"Student", "Professor", "Teaching Assistant", "Administrator"}));
		((DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
		GridBagConstraints gbc_spinner = new GridBagConstraints();
		gbc_spinner.gridwidth = 3;
		gbc_spinner.fill = GridBagConstraints.HORIZONTAL;
		gbc_spinner.anchor = GridBagConstraints.NORTH;
		gbc_spinner.insets = new Insets(0, 0, 5, 5);
		gbc_spinner.gridx = 1;
		gbc_spinner.gridy = 8;
		frame.getContentPane().add(spinner, gbc_spinner);
		GridBagConstraints gbc_btnLogIn = new GridBagConstraints();
		gbc_btnLogIn.insets = new Insets(0, 0, 0, 5);
		gbc_btnLogIn.gridx = 8;
		gbc_btnLogIn.gridy = 9;
		
		JButton btnLogIn = new JButton("Log In");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String type = spinner.getValue().toString();
				DataManager dm = new DataManager();
				LoginControl control = new LoginControl(dm);
				if (control.verifyLogin(txtLogin.getText(), txtPassword.getText(), type)) {
					switch (type) {
						case "Student":
							StudentView.openWindow();
				   			break;
				   		case "Professor":
				   			ProfView.openWindow();
				   			break;
				   		case "Administrator":
				   			AdminView.openWindow();
				   			break;
				   		case "Teaching Assistant":
				   			TAView.openWindow();
					}

					frame.setVisible(false);
					frame.dispose();
				} else {
					lblStatus.setText("Invalid login. Try again.");
				}
			}
		});
		frame.getContentPane().add(btnLogIn, gbc_btnLogIn);
		
		JButton btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnQuit = new GridBagConstraints();
		gbc_btnQuit.gridx = 9;
		gbc_btnQuit.gridy = 9;
		frame.getContentPane().add(btnQuit, gbc_btnQuit);
	}
}
