package menrva.ui;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import menrva.AdminView;
import menrva.DataManager;
import menrva.control.CreateCourseControl;
import menrva.entities.UserAccount;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JList;

public class CreateCourseUI {

	private JFrame frame;
	private JTextField txtId;
	private JTextField txtName;
	private JTextField txtLocation;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateCourseUI window = new CreateCourseUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CreateCourseUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		DataManager dm = new DataManager();
		CreateCourseControl control = new CreateCourseControl(dm);
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 390);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblCreateCourse = new JLabel("Manage Courses");
		lblCreateCourse.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_lblCreateCourse = new GridBagConstraints();
		gbc_lblCreateCourse.insets = new Insets(0, 0, 5, 5);
		gbc_lblCreateCourse.gridx = 1;
		gbc_lblCreateCourse.gridy = 1;
		frame.getContentPane().add(lblCreateCourse, gbc_lblCreateCourse);
		
		JLabel lblCourseId = new JLabel("Course ID");
		GridBagConstraints gbc_lblCourseId = new GridBagConstraints();
		gbc_lblCourseId.anchor = GridBagConstraints.EAST;
		gbc_lblCourseId.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourseId.gridx = 1;
		gbc_lblCourseId.gridy = 2;
		frame.getContentPane().add(lblCourseId, gbc_lblCourseId);
		
		txtId = new JTextField();
		GridBagConstraints gbc_txtId = new GridBagConstraints();
		gbc_txtId.gridwidth = 7;
		gbc_txtId.insets = new Insets(0, 0, 5, 5);
		gbc_txtId.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtId.gridx = 3;
		gbc_txtId.gridy = 2;
		frame.getContentPane().add(txtId, gbc_txtId);
		txtId.setColumns(10);
		
		JLabel lblFullCourseName = new JLabel("Full Course Name");
		GridBagConstraints gbc_lblFullCourseName = new GridBagConstraints();
		gbc_lblFullCourseName.anchor = GridBagConstraints.EAST;
		gbc_lblFullCourseName.insets = new Insets(0, 0, 5, 5);
		gbc_lblFullCourseName.gridx = 1;
		gbc_lblFullCourseName.gridy = 3;
		frame.getContentPane().add(lblFullCourseName, gbc_lblFullCourseName);
		
		txtName = new JTextField();
		GridBagConstraints gbc_txtName = new GridBagConstraints();
		gbc_txtName.gridwidth = 7;
		gbc_txtName.insets = new Insets(0, 0, 5, 5);
		gbc_txtName.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtName.gridx = 3;
		gbc_txtName.gridy = 3;
		frame.getContentPane().add(txtName, gbc_txtName);
		txtName.setColumns(10);
		
		JLabel lblProfessor = new JLabel("Professor(s)");
		GridBagConstraints gbc_lblProfessor = new GridBagConstraints();
		gbc_lblProfessor.anchor = GridBagConstraints.EAST;
		gbc_lblProfessor.insets = new Insets(0, 0, 5, 5);
		gbc_lblProfessor.gridx = 1;
		gbc_lblProfessor.gridy = 4;
		frame.getContentPane().add(lblProfessor, gbc_lblProfessor);
		
		
		DefaultListModel<Object> profModel = new DefaultListModel<>();
		JList lstProfs = new JList(profModel);
		GridBagConstraints gbc_lstProfs = new GridBagConstraints();
		gbc_lstProfs.gridwidth = 7;
		gbc_lstProfs.insets = new Insets(0, 0, 5, 5);
		gbc_lstProfs.fill = GridBagConstraints.BOTH;
		gbc_lstProfs.gridx = 3;
		gbc_lstProfs.gridy = 4;
		frame.getContentPane().add(lstProfs, gbc_lstProfs);
		
		// add existing professors to combo box
		for (UserAccount prof : control.getProfs()) {
			profModel.addElement(prof);
		}
		
		JLabel lblTeachingAssistants = new JLabel("Teaching Assistant(s)");
		GridBagConstraints gbc_lblTeachingAssistants = new GridBagConstraints();
		gbc_lblTeachingAssistants.anchor = GridBagConstraints.EAST;
		gbc_lblTeachingAssistants.insets = new Insets(0, 0, 5, 5);
		gbc_lblTeachingAssistants.gridx = 1;
		gbc_lblTeachingAssistants.gridy = 5;
		frame.getContentPane().add(lblTeachingAssistants, gbc_lblTeachingAssistants);
		
		DefaultListModel<Object> taModel = new DefaultListModel<>();
		JList lstTas = new JList(taModel);
		GridBagConstraints gbc_lstTas = new GridBagConstraints();
		gbc_lstTas.gridwidth = 7;
		gbc_lstTas.insets = new Insets(0, 0, 5, 5);
		gbc_lstTas.fill = GridBagConstraints.BOTH;
		gbc_lstTas.gridx = 3;
		gbc_lstTas.gridy = 5;
		frame.getContentPane().add(lstTas, gbc_lstTas);
		
		// add existing teaching assistants to form
		for (UserAccount ta : control.getTAs()) {
			taModel.addElement(ta);
		}
		
		JLabel lblLocation = new JLabel("Location");
		GridBagConstraints gbc_lblLocation = new GridBagConstraints();
		gbc_lblLocation.anchor = GridBagConstraints.EAST;
		gbc_lblLocation.insets = new Insets(0, 0, 5, 5);
		gbc_lblLocation.gridx = 1;
		gbc_lblLocation.gridy = 6;
		frame.getContentPane().add(lblLocation, gbc_lblLocation);
		
		txtLocation = new JTextField();
		GridBagConstraints gbc_txtLocation = new GridBagConstraints();
		gbc_txtLocation.gridwidth = 7;
		gbc_txtLocation.insets = new Insets(0, 0, 5, 5);
		gbc_txtLocation.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLocation.gridx = 3;
		gbc_txtLocation.gridy = 6;
		frame.getContentPane().add(txtLocation, gbc_txtLocation);
		txtLocation.setColumns(10);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   AdminView.openWindow();
				   frame.setVisible(false);
				   frame.dispose();
			}
		});
		
		JLabel lblDescription = new JLabel("Description");
		GridBagConstraints gbc_lblDescription = new GridBagConstraints();
		gbc_lblDescription.anchor = GridBagConstraints.EAST;
		gbc_lblDescription.insets = new Insets(0, 0, 5, 5);
		gbc_lblDescription.gridx = 1;
		gbc_lblDescription.gridy = 7;
		frame.getContentPane().add(lblDescription, gbc_lblDescription);
		
		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.gridheight = 3;
		gbc_textArea.gridwidth = 5;
		gbc_textArea.insets = new Insets(0, 0, 5, 5);
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridx = 5;
		gbc_textArea.gridy = 7;
		frame.getContentPane().add(textArea, gbc_textArea);
		
		JLabel lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.gridwidth = 5;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
		gbc_lblStatus.gridx = 5;
		gbc_lblStatus.gridy = 10;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataManager dm = new DataManager();
				CreateCourseControl control = new CreateCourseControl(dm);
				
				if (!txtId.getText().isEmpty() && control.verifyCourse(txtId.getText())) {
					lblStatus.setText("Deleting course...");
					if (control.deleteCourse(txtId.getText())) {
						lblStatus.setText("Course deleted successfully.");
					} else {
						lblStatus.setText("Provided course id does not exist.");
					}
				} else {
					lblStatus.setText("Please provide a valid course id.");
					return;
				}
			}
		});
		GridBagConstraints gbc_btnDelete = new GridBagConstraints();
		gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
		gbc_btnDelete.gridx = 7;
		gbc_btnDelete.gridy = 11;
		frame.getContentPane().add(btnDelete, gbc_btnDelete);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataManager dm = new DataManager();
				CreateCourseControl control = new CreateCourseControl(dm);
				
				Map<String, Object> form = new HashMap<>();
				
				if (!txtId.getText().isEmpty()) {
					lblCourseId.setText("Course ID");
					form.put("Id", txtId.getText().replace("'", "\\'"));
				} else {
					lblCourseId.setText("Course ID *");
					lblStatus.setText("Please provide a valid course id.");
					return;
				}
				
				if (!txtName.getText().isEmpty()) {
					form.put("Name", txtName.getText().replace("'", "\\'"));
				}
				if (!txtLocation.getText().isEmpty()) {
					form.put("Location", txtLocation.getText().replace("'", "\\'"));
				}
				if (!textArea.getText().isEmpty()) {
					form.put("Description", textArea.getText().replace("'", "\\'"));
				}

				List<String> profIds = new ArrayList<>();
				for (Object user : lstProfs.getSelectedValuesList()) {
					UserAccount prof = (UserAccount) user;
					profIds.add(prof.getId());
				}
				form.put("Professors", profIds);
				
				List<String> taIds = new ArrayList<>();
				for (Object user : lstTas.getSelectedValuesList()) {
					UserAccount ta = (UserAccount) user;
					taIds.add(ta.getId());
				}
				form.put("Teaching Assistants", taIds);
				
				if (control.verifyCourse(txtId.getText().replace("'", "\\'"))) {
					lblStatus.setText("Updating course...");
					if (control.udpateCourse(form)) {
						lblStatus.setText("Course updated successfully.");
					} else {
						lblStatus.setText("Error! Could not update course.");
					}
				} else {
					lblStatus.setText("Provided course id does not exist.");
				}
			}
		});
		GridBagConstraints gbc_btnUpdate = new GridBagConstraints();
		gbc_btnUpdate.insets = new Insets(0, 0, 5, 5);
		gbc_btnUpdate.gridx = 8;
		gbc_btnUpdate.gridy = 11;
		frame.getContentPane().add(btnUpdate, gbc_btnUpdate);
		
		JButton btnSubmit = new JButton("Create");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataManager dm = new DataManager();
				CreateCourseControl control = new CreateCourseControl(dm);
				
				Map<String, Object> form = new HashMap<>();
				
				if (!txtId.getText().isEmpty()) {
					lblCourseId.setText("Course ID");
					if (control.verifyCourse(txtId.getText().replace("'", "\\'"))) {
						lblStatus.setText("Oops! A Course having this ID already exists.");
						return;
					}
					form.put("Id", txtId.getText().replace("'", "\\'"));
				} else {
					lblCourseId.setText("Course ID *");
					lblStatus.setText("Please provide information for required fields.");
					return;
				}
				if (!txtName.getText().isEmpty()) {
					form.put("Name", txtName.getText().replace("'", "\\'"));
				}
				if (!txtLocation.getText().isEmpty()) {
					form.put("Location", txtLocation.getText().replace("'", "\\'"));
				}
				if (!textArea.getText().isEmpty()) {
					form.put("Description", textArea.getText().replace("'", "\\'"));
				}

				List<String> profIds = new ArrayList<>();
				for (Object user : lstProfs.getSelectedValuesList()) {
					UserAccount prof = (UserAccount) user;
					profIds.add(prof.getId());
				}
				form.put("Professors", profIds);
				
				List<String> taIds = new ArrayList<>();
				for (Object user : lstTas.getSelectedValuesList()) {
					UserAccount ta = (UserAccount) user;
					taIds.add(ta.getId());
				}
				form.put("Teaching Assistants", taIds);
				
				lblStatus.setText("Creating course...");
				if (control.saveCourse(form)) {
					lblStatus.setText("Course created successfully.");
				} else {
					lblStatus.setText("Error! Could not create course.");
				}
			}
		});
		
		GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
		gbc_btnSubmit.insets = new Insets(0, 0, 5, 5);
		gbc_btnSubmit.gridx = 9;
		gbc_btnSubmit.gridy = 11;
		frame.getContentPane().add(btnSubmit, gbc_btnSubmit);
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 0, 5);
		gbc_btnBack.gridx = 1;
		gbc_btnBack.gridy = 13;
		frame.getContentPane().add(btnBack, gbc_btnBack);
	}

}
