package menrva.entities;

public class Grade {
	private int id;
	private Assignment assignment;
	private Course course;
	private UserAccount student;
	private double grade;
	
	public int getId() {
		return id;
	}
	
	public void setId(int newId) {
		id = newId;
	}
	
	public Assignment getAssignment() {
		return assignment;
	}
	
	public void setAssignment(Assignment newAssignment) {
		assignment = newAssignment;
	}
	
	public Course getCourse() {
		return course;
	}
	
	public void setCourse(Course newCourse) {
		course = newCourse;
	}
	
	public UserAccount getStudent() {
		return student;
	}
	
	public void setStudent(UserAccount newStudent) {
		student = newStudent;
	}
	
	public double getGrade() {
		return grade;
	}
	
	public void setGrade(double newGrade) {
		grade = newGrade;
	}

}
