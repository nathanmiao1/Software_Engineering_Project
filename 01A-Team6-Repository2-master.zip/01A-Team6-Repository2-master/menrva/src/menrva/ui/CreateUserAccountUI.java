package menrva.ui;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import menrva.AdminView;
import menrva.DataManager;
import menrva.control.CreateUserAccountControl;
import menrva.util.CyclingSpinnerListModel;

import javax.swing.JSpinner;
import javax.swing.JTextPane;
import javax.swing.JSpinner.DefaultEditor;
import java.awt.Font;

public class CreateUserAccountUI {

	private JFrame frame;
	private JTextField txtId;
	private JTextField txtPassword;
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextField txtAddress;
	private JTextField txtContactInfo;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateUserAccountUI window = new CreateUserAccountUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CreateUserAccountUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblCreateUser = new JLabel("Manage Accounts");
		lblCreateUser.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_lblCreateUser = new GridBagConstraints();
		gbc_lblCreateUser.anchor = GridBagConstraints.WEST;
		gbc_lblCreateUser.gridwidth = 6;
		gbc_lblCreateUser.insets = new Insets(0, 0, 5, 5);
		gbc_lblCreateUser.gridx = 1;
		gbc_lblCreateUser.gridy = 1;
		frame.getContentPane().add(lblCreateUser, gbc_lblCreateUser);
		
		JLabel lblLoginId = new JLabel("Login ID");
		GridBagConstraints gbc_lblLoginId = new GridBagConstraints();
		gbc_lblLoginId.anchor = GridBagConstraints.EAST;
		gbc_lblLoginId.insets = new Insets(0, 0, 5, 5);
		gbc_lblLoginId.gridx = 1;
		gbc_lblLoginId.gridy = 2;
		frame.getContentPane().add(lblLoginId, gbc_lblLoginId);
		
		txtId = new JTextField();
		GridBagConstraints gbc_txtId = new GridBagConstraints();
		gbc_txtId.gridwidth = 3;
		gbc_txtId.insets = new Insets(0, 0, 5, 5);
		gbc_txtId.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtId.gridx = 3;
		gbc_txtId.gridy = 2;
		frame.getContentPane().add(txtId, gbc_txtId);
		txtId.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.anchor = GridBagConstraints.EAST;
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 1;
		gbc_lblPassword.gridy = 3;
		frame.getContentPane().add(lblPassword, gbc_lblPassword);
		
		txtPassword = new JTextField();
		GridBagConstraints gbc_txtPassword = new GridBagConstraints();
		gbc_txtPassword.gridwidth = 3;
		gbc_txtPassword.insets = new Insets(0, 0, 5, 5);
		gbc_txtPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtPassword.gridx = 3;
		gbc_txtPassword.gridy = 3;
		frame.getContentPane().add(txtPassword, gbc_txtPassword);
		txtPassword.setColumns(10);
		
		JLabel lblFirstName = new JLabel("First Name");
		GridBagConstraints gbc_lblFirstName = new GridBagConstraints();
		gbc_lblFirstName.anchor = GridBagConstraints.EAST;
		gbc_lblFirstName.insets = new Insets(0, 0, 5, 5);
		gbc_lblFirstName.gridx = 1;
		gbc_lblFirstName.gridy = 4;
		frame.getContentPane().add(lblFirstName, gbc_lblFirstName);
		
		txtFirstName = new JTextField();
		GridBagConstraints gbc_txtFirstName = new GridBagConstraints();
		gbc_txtFirstName.gridwidth = 3;
		gbc_txtFirstName.insets = new Insets(0, 0, 5, 5);
		gbc_txtFirstName.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFirstName.gridx = 3;
		gbc_txtFirstName.gridy = 4;
		frame.getContentPane().add(txtFirstName, gbc_txtFirstName);
		txtFirstName.setColumns(10);
		
		JLabel lblLastName = new JLabel("Last Name");
		GridBagConstraints gbc_lblLastName = new GridBagConstraints();
		gbc_lblLastName.anchor = GridBagConstraints.EAST;
		gbc_lblLastName.insets = new Insets(0, 0, 5, 5);
		gbc_lblLastName.gridx = 1;
		gbc_lblLastName.gridy = 5;
		frame.getContentPane().add(lblLastName, gbc_lblLastName);
		
		txtLastName = new JTextField();
		GridBagConstraints gbc_txtLastName = new GridBagConstraints();
		gbc_txtLastName.gridwidth = 3;
		gbc_txtLastName.insets = new Insets(0, 0, 5, 5);
		gbc_txtLastName.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLastName.gridx = 3;
		gbc_txtLastName.gridy = 5;
		frame.getContentPane().add(txtLastName, gbc_txtLastName);
		txtLastName.setColumns(10);
		gbc_lblLastName.insets = new Insets(0, 0, 5, 5);
		gbc_lblLastName.gridx = 1;
		gbc_lblLastName.gridy = 6;
		gbc_txtLastName.gridwidth = 3;
		gbc_txtLastName.insets = new Insets(0, 0, 5, 5);
		gbc_txtLastName.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLastName.gridx = 3;
		gbc_txtLastName.gridy = 6;
		gbc_lblLastName.insets = new Insets(0, 0, 5, 5);
		gbc_lblLastName.gridx = 1;
		gbc_lblLastName.gridy = 7;
		gbc_txtLastName.gridwidth = 3;
		gbc_txtLastName.insets = new Insets(0, 0, 5, 5);
		gbc_txtLastName.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLastName.gridx = 3;
		gbc_txtLastName.gridy = 7;
		
		JLabel lblType = new JLabel("Role");
		GridBagConstraints gbc_lblType = new GridBagConstraints();
		gbc_lblType.anchor = GridBagConstraints.EAST;
		gbc_lblType.insets = new Insets(0, 0, 5, 5);
		gbc_lblType.gridx = 1;
		gbc_lblType.gridy = 6;
		frame.getContentPane().add(lblType, gbc_lblType);
		
		JSpinner spinner = new JSpinner(new CyclingSpinnerListModel(new String[] {"Student", "Professor", "Teaching Assistant", "Administrator"}));
		((DefaultEditor) spinner.getEditor()).getTextField().setEditable(false);
		GridBagConstraints gbc_spinner = new GridBagConstraints();
		gbc_spinner.fill = GridBagConstraints.HORIZONTAL;
		gbc_spinner.gridwidth = 3;
		gbc_spinner.insets = new Insets(0, 0, 5, 5);
		gbc_spinner.gridx = 3;
		gbc_spinner.gridy = 6;
		frame.getContentPane().add(spinner, gbc_spinner);
		
		JLabel lblAddress = new JLabel("Address");
		GridBagConstraints gbc_lblAddress = new GridBagConstraints();
		gbc_lblAddress.anchor = GridBagConstraints.EAST;
		gbc_lblAddress.insets = new Insets(0, 0, 5, 5);
		gbc_lblAddress.gridx = 1;
		gbc_lblAddress.gridy = 7;
		frame.getContentPane().add(lblAddress, gbc_lblAddress);
		
		txtAddress = new JTextField();
		GridBagConstraints gbc_txtAddress = new GridBagConstraints();
		gbc_txtAddress.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtAddress.gridwidth = 3;
		gbc_txtAddress.insets = new Insets(0, 0, 5, 5);
		gbc_txtAddress.gridx = 3;
		gbc_txtAddress.gridy = 7;
		frame.getContentPane().add(txtAddress, gbc_txtAddress);
		txtAddress.setColumns(10);
		
		JLabel lblContactInfo = new JLabel("Contact Info");
		GridBagConstraints gbc_lblContactInfo = new GridBagConstraints();
		gbc_lblContactInfo.anchor = GridBagConstraints.EAST;
		gbc_lblContactInfo.insets = new Insets(0, 0, 5, 5);
		gbc_lblContactInfo.gridx = 1;
		gbc_lblContactInfo.gridy = 8;
		frame.getContentPane().add(lblContactInfo, gbc_lblContactInfo);
		
		txtContactInfo = new JTextField();
		GridBagConstraints gbc_txtContactInfo = new GridBagConstraints();
		gbc_txtContactInfo.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtContactInfo.gridwidth = 3;
		gbc_txtContactInfo.insets = new Insets(0, 0, 5, 5);
		gbc_txtContactInfo.gridx = 3;
		gbc_txtContactInfo.gridy = 8;
		frame.getContentPane().add(txtContactInfo, gbc_txtContactInfo);
		txtContactInfo.setColumns(10);
		
		JLabel lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.gridwidth = 3;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
		gbc_lblStatus.gridx = 3;
		gbc_lblStatus.gridy = 9;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		
		JButton btnSubmit = new JButton("Create");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateUserAccountControl control = new CreateUserAccountControl(new DataManager());
				Map<String, String> form = new HashMap<>();
				
				if (!txtId.getText().isEmpty()) {
					if (control.verifyAccount(txtId.getText().replace("'", "\\'"))) {
						lblStatus.setText("Oops! An Account having this Login ID already exists.");
						return;
					}
					lblLoginId.setText("Login ID");
					form.put("Id", txtId.getText().replace("'", "\\'"));
				} else {
					lblLoginId.setText("Login ID *");
					lblStatus.setText("Please provide information for required fields.");
					return;
				}
				if (!txtFirstName.getText().isEmpty()) {
					form.put("FirstName", txtFirstName.getText().replace("'", "\\'"));
				}
				if (!txtLastName.getText().isEmpty()) {
					form.put("LastName", txtLastName.getText().replace("'", "\\'"));
				}
				if (!txtAddress.getText().isEmpty()) {
					form.put("Address", txtAddress.getText().replace("'", "\\'"));
				}
				if (!txtContactInfo.getText().isEmpty()) {
					form.put("ContactInfo", txtContactInfo.getText().replace("'", "\\'"));
				}
				
				form.put("Type", spinner.getValue().toString());
				
				if (!txtPassword.getText().isEmpty()) {
					lblPassword.setText("Password");
					form.put("Password", txtPassword.getText().replace("'", "\\'"));

					lblStatus.setText("Creating account...");
					if (control.createAccount(form)) {
						lblStatus.setText("Account created successfully.");
					} else {
						lblStatus.setText("Error! Could not create account.");
					}
				} else {
					lblPassword.setText("Password *");
					lblStatus.setText("Please provide information for required fields.");
				}
			}
		});
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateUserAccountControl control = new CreateUserAccountControl(new DataManager());
				if (!txtId.getText().isEmpty() && control.verifyAccount(txtId.getText().replace("'", "\\'"))) {
					lblStatus.setText("Deleting account...");
					if (control.deleteAccount(txtId.getText().replace("'", "\\'"))) {
						lblStatus.setText("Account deleted successfully.");
					} else {
						lblStatus.setText("Error! Could not delete account.");
					}
				} else {
					lblStatus.setText("Please provide a valid account id.");
					return;
				}
			}
		});
		GridBagConstraints gbc_btnDelete = new GridBagConstraints();
		gbc_btnDelete.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
		gbc_btnDelete.gridx = 3;
		gbc_btnDelete.gridy = 10;
		frame.getContentPane().add(btnDelete, gbc_btnDelete);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateUserAccountControl control = new CreateUserAccountControl(new DataManager());
				Map<String, String> form = new HashMap<>();
				
				if (!txtId.getText().isEmpty() && control.verifyAccount(txtId.getText().replace("'", "\\'"))) {
					form.put("Id", txtId.getText().replace("'", "\\'"));
				} else {
					lblStatus.setText("Please provide a valid account id.");
					return;
				}
				if (!txtPassword.getText().isEmpty()) {
					form.put("Password", txtPassword.getText().replace("'", "\\'"));
				}
				if (!txtFirstName.getText().isEmpty()) {
					form.put("FirstName", txtFirstName.getText().replace("'", "\\'"));
				}
				if (!txtLastName.getText().isEmpty()) {
					form.put("LastName", txtLastName.getText().replace("'", "\\'"));
				}
				if (!txtAddress.getText().isEmpty()) {
					form.put("Address", txtAddress.getText().replace("'", "\\'"));
				}
				if (!txtContactInfo.getText().isEmpty()) {
					form.put("ContactInfo", txtContactInfo.getText().replace("'", "\\'"));
				}
				
				form.put("Type", spinner.getValue().toString());
				
				lblStatus.setText("Updating account...");
				if (control.updateAccount(form)) {
					lblStatus.setText("Account updated successfully.");
				} else {
					lblStatus.setText("Error! Could not update account.");
				}
			}
		});
		GridBagConstraints gbc_btnUpdate = new GridBagConstraints();
		gbc_btnUpdate.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnUpdate.insets = new Insets(0, 0, 5, 5);
		gbc_btnUpdate.gridx = 4;
		gbc_btnUpdate.gridy = 10;
		frame.getContentPane().add(btnUpdate, gbc_btnUpdate);
		GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
		gbc_btnSubmit.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnSubmit.insets = new Insets(0, 0, 5, 5);
		gbc_btnSubmit.gridx = 5;
		gbc_btnSubmit.gridy = 10;
		frame.getContentPane().add(btnSubmit, gbc_btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			   AdminView.openWindow();
			   frame.setVisible(false);
			   frame.dispose();
			}
		});
		
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.anchor = GridBagConstraints.WEST;
		gbc_btnBack.insets = new Insets(0, 0, 5, 5);
		gbc_btnBack.gridx = 1;
		gbc_btnBack.gridy = 11;
		frame.getContentPane().add(btnBack, gbc_btnBack);
	}

}
