package menrva.ui;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;

import menrva.DataManager;
import menrva.ProfView;
import menrva.StudentView;
import menrva.TAView;
import menrva.control.DownloadRubricControl;
import menrva.control.LoginControl;
import menrva.entities.Course;
import menrva.entities.MenrvaFile;
import menrva.entities.Rubric;

public class DownloadRubricUI {

	private JFrame frame;
	private JButton btnDownload;
	private JLabel lblSubmitAssignment;
	private JComboBox cmbCourse;
	private JButton btnRefreshAssignments;
	private JLabel lblCourse;
	private JLabel lblStatus;
	private JLabel lblSubmissions;
	private JList list;
	private DefaultListModel<Object> model;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DownloadRubricUI window = new DownloadRubricUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DownloadRubricUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		DownloadRubricControl control = new DownloadRubricControl(new DataManager());
		model = new DefaultListModel<>();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 510, 315);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		lblSubmitAssignment = new JLabel("Download Rubric");
		lblSubmitAssignment.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_lblSubmitAssignment = new GridBagConstraints();
		gbc_lblSubmitAssignment.anchor = GridBagConstraints.WEST;
		gbc_lblSubmitAssignment.gridwidth = 11;
		gbc_lblSubmitAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_lblSubmitAssignment.gridx = 1;
		gbc_lblSubmitAssignment.gridy = 1;
		frame.getContentPane().add(lblSubmitAssignment, gbc_lblSubmitAssignment);
		
		lblCourse = new JLabel("Course");
		GridBagConstraints gbc_lblCourse = new GridBagConstraints();
		gbc_lblCourse.gridwidth = 5;
		gbc_lblCourse.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourse.anchor = GridBagConstraints.EAST;
		gbc_lblCourse.gridx = 1;
		gbc_lblCourse.gridy = 2;
		frame.getContentPane().add(lblCourse, gbc_lblCourse);
		
		cmbCourse = new JComboBox();
		GridBagConstraints gbc_cmbCourse = new GridBagConstraints();
		gbc_cmbCourse.gridwidth = 7;
		gbc_cmbCourse.insets = new Insets(0, 0, 5, 5);
		gbc_cmbCourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbCourse.gridx = 6;
		gbc_cmbCourse.gridy = 2;
		frame.getContentPane().add(cmbCourse, gbc_cmbCourse);
		
		// add user courses to form
		for (Course course : control.getCourses()) {
			cmbCourse.addItem(course);
		}
		
		btnRefreshAssignments = new JButton("Refresh Rubrics");
		btnRefreshAssignments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.clear();
				for (Rubric rubric : control.getRubrics(((Course)cmbCourse.getSelectedItem()).getId())) {
					model.addElement(rubric);
				}
			}
		});
		GridBagConstraints gbc_btnRefreshAssignments = new GridBagConstraints();
		gbc_btnRefreshAssignments.insets = new Insets(0, 0, 5, 0);
		gbc_btnRefreshAssignments.gridx = 13;
		gbc_btnRefreshAssignments.gridy = 2;
		frame.getContentPane().add(btnRefreshAssignments, gbc_btnRefreshAssignments);
		
		list = new JList(model);
		GridBagConstraints gbc_list = new GridBagConstraints();
		gbc_list.gridheight = 3;
		gbc_list.gridwidth = 8;
		gbc_list.insets = new Insets(0, 0, 5, 5);
		gbc_list.fill = GridBagConstraints.BOTH;
		gbc_list.gridx = 6;
		gbc_list.gridy = 3;
		frame.getContentPane().add(list, gbc_list);
		
		lblSubmissions = new JLabel("Rubrics");
		GridBagConstraints gbc_lblSubmissions = new GridBagConstraints();
		gbc_lblSubmissions.gridwidth = 5;
		gbc_lblSubmissions.anchor = GridBagConstraints.EAST;
		gbc_lblSubmissions.insets = new Insets(0, 0, 5, 5);
		gbc_lblSubmissions.gridx = 1;
		gbc_lblSubmissions.gridy = 4;
		frame.getContentPane().add(lblSubmissions, gbc_lblSubmissions);
		
		btnDownload = new JButton("Download");
		btnDownload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (list.getSelectedValuesList().isEmpty()) {
					lblStatus.setText("Oops! No rubric(s) selected.");
					return;
				}
				ArrayList<Integer> ids = new ArrayList<>();
				for (Object item : list.getSelectedValuesList()) {
					ids.add(((Rubric) item).getFile().getId());
				}
				if (control.downloadFiles(ids)) {
					lblStatus.setText("Successfully downloaded rubric(s).");
				} else {
					lblStatus.setText("Error! Could not download rubric(s).");
				}
			}
		});
		GridBagConstraints gbc_btnDownload = new GridBagConstraints();
		gbc_btnDownload.anchor = GridBagConstraints.WEST;
		gbc_btnDownload.gridwidth = 8;
		gbc_btnDownload.insets = new Insets(0, 0, 5, 5);
		gbc_btnDownload.gridx = 6;
		gbc_btnDownload.gridy = 6;
		frame.getContentPane().add(btnDownload, gbc_btnDownload);
		
		lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.anchor = GridBagConstraints.WEST;
		gbc_lblStatus.gridwidth = 8;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
		gbc_lblStatus.gridx = 6;
		gbc_lblStatus.gridy = 7;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String type = LoginControl.user.getType();
				if (type == "Student") {
					StudentView.openWindow();
				} else if (type == "Professor") {
					ProfView.openWindow();
				} else {
					TAView.openWindow();
				}
				frame.setVisible(false);	
				frame.dispose();				
			}
		});
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.gridwidth = 2;
		gbc_btnBack.insets = new Insets(0, 0, 5, 5);
		gbc_btnBack.gridx = 1;
		gbc_btnBack.gridy = 8;
		frame.getContentPane().add(btnBack, gbc_btnBack);
	}

}
