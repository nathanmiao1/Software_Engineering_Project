package menrva;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import menrva.ui.DownloadRubricUI;
import menrva.ui.LockerUI;
import menrva.ui.LoginUI;
import menrva.ui.UploadAssignmentFileUI;
import menrva.ui.ViewGradesUI;

public class StudentView {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentView window = new StudentView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		
		JLabel lblWelcomeStudent = new JLabel("Welcome, Student");
		GridBagConstraints gbc_lblWelcomeStudent = new GridBagConstraints();
		gbc_lblWelcomeStudent.insets = new Insets(0, 0, 5, 5);
		gbc_lblWelcomeStudent.gridx = 2;
		gbc_lblWelcomeStudent.gridy = 1;
		frame.getContentPane().add(lblWelcomeStudent, gbc_lblWelcomeStudent);
		GridBagConstraints gbc_btnLogOut = new GridBagConstraints();
		gbc_btnLogOut.insets = new Insets(0, 0, 5, 5);
		gbc_btnLogOut.gridx = 10;
		gbc_btnLogOut.gridy = 1;
		frame.getContentPane().add(btnLogOut, gbc_btnLogOut);
		
		JButton btnUploadAssignment = new JButton("Submit Assignment");
		btnUploadAssignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UploadAssignmentFileUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnUploadAssignment = new GridBagConstraints();
		gbc_btnUploadAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_btnUploadAssignment.gridx = 2;
		gbc_btnUploadAssignment.gridy = 3;
		frame.getContentPane().add(btnUploadAssignment, gbc_btnUploadAssignment);
		
		JButton btnDownloadRubric = new JButton("Download Rubric");
		btnDownloadRubric.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DownloadRubricUI.openWindow();
				frame.setVisible(false);
			    frame.dispose();
			}
		});
		GridBagConstraints gbc_btnDownloadRubric = new GridBagConstraints();
		gbc_btnDownloadRubric.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnDownloadRubric.insets = new Insets(0, 0, 5, 5);
		gbc_btnDownloadRubric.gridx = 2;
		gbc_btnDownloadRubric.gridy = 5;
		frame.getContentPane().add(btnDownloadRubric, gbc_btnDownloadRubric);
    
    
    JButton btnDownloadLockerFile = new JButton("Locker");
		btnDownloadLockerFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LockerUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnDownloadLockerFile = new GridBagConstraints();
		gbc_btnDownloadLockerFile.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnDownloadLockerFile.insets = new Insets(0, 0, 5, 5);
		gbc_btnDownloadLockerFile.gridx = 2;
		gbc_btnDownloadLockerFile.gridy = 4;
		frame.getContentPane().add(btnDownloadLockerFile, gbc_btnDownloadLockerFile);
		
		JButton btnViewGrades = new JButton("View Grades");
		btnViewGrades.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewGradesUI.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnViewGrades = new GridBagConstraints();
		gbc_btnViewGrades.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnViewGrades.insets = new Insets(0, 0, 0, 5);
		gbc_btnViewGrades.gridx = 2;
		gbc_btnViewGrades.gridy = 6;
		frame.getContentPane().add(btnViewGrades, gbc_btnViewGrades);
	}

}
