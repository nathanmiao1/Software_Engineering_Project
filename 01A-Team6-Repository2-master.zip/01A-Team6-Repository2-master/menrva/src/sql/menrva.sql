create table UserAccounts(
    Id varchar(20),
    Password varchar(200),
    Type varchar(50),
    FirstName varchar(20),
    LastName varchar(20),
    Address varchar(50),
    ContactInfo varchar(50),
    primary key (Id));

insert into UserAccounts values('root', sha1('root'), 'Administrator', 'System', 'User', '550 Windsor St, Fredericton, NB','root@root.com');

create table Courses(
    Id varchar(20),
    Name varchar(100),
    Location varchar(100),
    primary key (Id));

create table UserCourseLinks(
    UserId varchar(20),
    CourseId varchar(20),
    Type varchar(50));

create table Assignments(
    Id int auto_increment,
    CourseId varchar(20),
    Name varchar(100),
    primary key (Id));

create table Files(
    Id int auto_increment,
    Name varchar(100),
    File LONGBLOB,
    primary key (Id));

create table AssignmentFileLinks(
    FileId int,
    AssignmentId int,
    Type varchar(50));
    
create table Grades(
	AssignmentId int,
	StudentId varchar(20),
	CourseId varchar(20),
	Grade FLOAT,
	Weight FLOAT,
	primary key (StudentId, CourseID, AssignmentId));

create table Rubrics(
	FileId int,
	CourseId varchar(20)
)
               
create table Lockers(
	StudentId varchar(20),
	FileId int
);