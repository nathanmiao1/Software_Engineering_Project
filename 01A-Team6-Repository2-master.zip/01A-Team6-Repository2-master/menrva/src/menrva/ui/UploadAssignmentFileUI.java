package menrva.ui;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import menrva.DataManager;
import menrva.StudentView;
import menrva.control.UploadAssignmentFileControl;
import menrva.entities.Assignment;
import menrva.entities.Course;

public class UploadAssignmentFileUI {

	private JFrame frame;
	private JTextField txtFile;
	private JButton btnUploadFile;
	private JLabel lblSubmitAssignment;
	private JComboBox cmbCourse;
	private JButton btnRefreshAssignments;
	private JComboBox cmbAssignment;
	private JLabel lblCourse;
	private JLabel lblAssignment;
	private JLabel lblStatus;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UploadAssignmentFileUI window = new UploadAssignmentFileUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UploadAssignmentFileUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		UploadAssignmentFileControl control = new UploadAssignmentFileControl(new DataManager());
		
		frame = new JFrame();
		frame.setBounds(100, 100, 510, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		lblSubmitAssignment = new JLabel("Submit Assignment");
		lblSubmitAssignment.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_lblSubmitAssignment = new GridBagConstraints();
		gbc_lblSubmitAssignment.anchor = GridBagConstraints.WEST;
		gbc_lblSubmitAssignment.gridwidth = 9;
		gbc_lblSubmitAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_lblSubmitAssignment.gridx = 2;
		gbc_lblSubmitAssignment.gridy = 1;
		frame.getContentPane().add(lblSubmitAssignment, gbc_lblSubmitAssignment);
		
		lblCourse = new JLabel("Course");
		GridBagConstraints gbc_lblCourse = new GridBagConstraints();
		gbc_lblCourse.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourse.anchor = GridBagConstraints.EAST;
		gbc_lblCourse.gridx = 2;
		gbc_lblCourse.gridy = 2;
		frame.getContentPane().add(lblCourse, gbc_lblCourse);
		
		cmbCourse = new JComboBox();
		GridBagConstraints gbc_cmbCourse = new GridBagConstraints();
		gbc_cmbCourse.gridwidth = 6;
		gbc_cmbCourse.insets = new Insets(0, 0, 5, 5);
		gbc_cmbCourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbCourse.gridx = 4;
		gbc_cmbCourse.gridy = 2;
		frame.getContentPane().add(cmbCourse, gbc_cmbCourse);
		
		// add user courses to form
		for (Course course : control.getCourses()) {
			cmbCourse.addItem(course);
		}
		
		btnRefreshAssignments = new JButton("Refresh Assignments");
		btnRefreshAssignments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cmbAssignment.removeAllItems();
				for (Assignment assignment : control.getAssignments(((Course)cmbCourse.getSelectedItem()).getId())) {
					cmbAssignment.addItem(assignment);
				}
			}
		});
		GridBagConstraints gbc_btnRefreshAssignments = new GridBagConstraints();
		gbc_btnRefreshAssignments.insets = new Insets(0, 0, 5, 5);
		gbc_btnRefreshAssignments.gridx = 10;
		gbc_btnRefreshAssignments.gridy = 2;
		frame.getContentPane().add(btnRefreshAssignments, gbc_btnRefreshAssignments);
		
		lblAssignment = new JLabel("Assignment");
		GridBagConstraints gbc_lblAssignment = new GridBagConstraints();
		gbc_lblAssignment.anchor = GridBagConstraints.EAST;
		gbc_lblAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_lblAssignment.gridx = 2;
		gbc_lblAssignment.gridy = 3;
		frame.getContentPane().add(lblAssignment, gbc_lblAssignment);
		
		cmbAssignment = new JComboBox();
		GridBagConstraints gbc_cmbAssignment = new GridBagConstraints();
		gbc_cmbAssignment.gridwidth = 6;
		gbc_cmbAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_cmbAssignment.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbAssignment.gridx = 4;
		gbc_cmbAssignment.gridy = 3;
		frame.getContentPane().add(cmbAssignment, gbc_cmbAssignment);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   StudentView.openWindow();
				   frame.setVisible(false);
				   frame.dispose();				
			}
		});
		
		txtFile = new JTextField();
		GridBagConstraints gbc_txtFile = new GridBagConstraints();
		gbc_txtFile.gridwidth = 6;
		gbc_txtFile.insets = new Insets(0, 0, 5, 5);
		gbc_txtFile.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFile.gridx = 4;
		gbc_txtFile.gridy = 5;
		frame.getContentPane().add(txtFile, gbc_txtFile);
		txtFile.setColumns(10);
		
		JButton btnBrowse = new JButton("Browse");
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.showOpenDialog(null);
				File file = fileChooser.getSelectedFile();
				String fileName = file.getAbsolutePath();
				txtFile.setText(fileName);
			}
		});
		GridBagConstraints gbc_btnBrowse = new GridBagConstraints();
		gbc_btnBrowse.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnBrowse.insets = new Insets(0, 0, 5, 5);
		gbc_btnBrowse.gridx = 10;
		gbc_btnBrowse.gridy = 5;
		frame.getContentPane().add(btnBrowse, gbc_btnBrowse);
		
		btnUploadFile = new JButton("Upload File");
		btnUploadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cmbAssignment.getSelectedItem() == null) {
					lblStatus.setText("Oops! No assignment is selected.");
					return;
				}
				try {
					File file = new File(txtFile.getText());
					if (!file.canWrite() || !file.canRead()) {
						throw new Exception();
					}
					lblStatus.setText("Uploading selected file...");
					if (control.saveAssignmentFile(file, ((Assignment) cmbAssignment.getSelectedItem()).getId())) {
						lblStatus.setText("File uploaded successfully.");
					} else {
						lblStatus.setText("Could not upload file.");
					}
				} catch(Exception ex) {
					lblStatus.setText("Cannot find specified file.");
				}
			}
		});
		GridBagConstraints gbc_btnUploadFile = new GridBagConstraints();
		gbc_btnUploadFile.anchor = GridBagConstraints.WEST;
		gbc_btnUploadFile.insets = new Insets(0, 0, 5, 5);
		gbc_btnUploadFile.gridx = 4;
		gbc_btnUploadFile.gridy = 6;
		frame.getContentPane().add(btnUploadFile, gbc_btnUploadFile);
		
		lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.anchor = GridBagConstraints.WEST;
		gbc_lblStatus.gridwidth = 7;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
		gbc_lblStatus.gridx = 4;
		gbc_lblStatus.gridy = 7;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 0, 5);
		gbc_btnBack.gridx = 2;
		gbc_btnBack.gridy = 9;
		frame.getContentPane().add(btnBack, gbc_btnBack);
	}

}
