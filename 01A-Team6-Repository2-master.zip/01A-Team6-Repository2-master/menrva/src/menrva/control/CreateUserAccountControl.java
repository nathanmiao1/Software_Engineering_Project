package menrva.control;

import java.util.Map;

import menrva.DataManager;

public class CreateUserAccountControl {
	DataManager dm;

	public CreateUserAccountControl(DataManager dm) {
		this.dm = dm;
	}
	
	public boolean createAccount(Map<String, String> form) {
		return dm.saveAccount(form);
	}
	
	public boolean updateAccount(Map<String, String> form) {
		return dm.updateAccount(form);
	}
	
	/**
	 * Check to see if the user already exists in the database.
	 * @param id
	 * @return <code>true</code> if the user does not exist, <code>false</code> otherwise
	 */
	public boolean verifyAccount(String id) {
		return dm.getUserAccount(id) != null? true : false; 
	}
	
	public boolean deleteAccount(String id) {
		return dm.deleteAccount(id);
	}
}
