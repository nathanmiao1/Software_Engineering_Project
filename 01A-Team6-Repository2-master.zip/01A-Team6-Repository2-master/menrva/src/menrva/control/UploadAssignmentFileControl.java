package menrva.control;

import java.io.File;
import java.util.List;

import menrva.DataManager;
import menrva.entities.Assignment;
import menrva.entities.Course;

public class UploadAssignmentFileControl {
	DataManager dm;

	public UploadAssignmentFileControl(DataManager dm) {
		this.dm = dm;
	}

	public boolean saveAssignmentFile(File file, Integer assignmentId) {
		return dm.saveAssignmentFile(file, assignmentId);
	}
	
	public List<Course> getCourses() {
		return dm.getCourses(LoginControl.user.getId(), "Student");
	}
	
	public List<Assignment> getAssignments(String courseId) {
		return dm.getAssignments(courseId);
	}
}
