package menrva.ui;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

import menrva.DataManager;
import menrva.StudentView;
import menrva.control.LockerControl;
import menrva.entities.MenrvaFile;

public class LockerUI {

	private JFrame frame;
	private JTextField txtFile;
	private DefaultListModel<Object> model;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LockerUI window = new LockerUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the application.
	 */
	public LockerUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		LockerControl control = new LockerControl(new DataManager());
		model = new DefaultListModel<>();
		frame = new JFrame();
		frame.setBounds(100, 100, 483, 320);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentView.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		
		JList list = new JList(model);
		GridBagConstraints gbc_list = new GridBagConstraints();
		gbc_list.gridwidth = 9;
		gbc_list.insets = new Insets(0, 0, 5, 5);
		gbc_list.fill = GridBagConstraints.BOTH;
		gbc_list.gridx = 3;
		gbc_list.gridy = 3;
		frame.getContentPane().add(list, gbc_list);
		
		JLabel lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.gridwidth = 10;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 0);
		gbc_lblStatus.gridx = 3;
		gbc_lblStatus.gridy = 5;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		
		JLabel lblMyLocker = new JLabel("My Locker");
		lblMyLocker.setFont(new Font("Tahoma", Font.BOLD, 12));
		GridBagConstraints gbc_lblMyLocker = new GridBagConstraints();
		gbc_lblMyLocker.gridwidth = 11;
		gbc_lblMyLocker.insets = new Insets(0, 0, 5, 5);
		gbc_lblMyLocker.gridx = 1;
		gbc_lblMyLocker.gridy = 2;
		frame.getContentPane().add(lblMyLocker, gbc_lblMyLocker);
		
		JButton btnDownload = new JButton("Download");
		btnDownload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!list.getSelectedValuesList().isEmpty()) {
					List<Integer> ids = new ArrayList<>();
					for (Object item : list.getSelectedValuesList()) {
						MenrvaFile file = (MenrvaFile) item;
						ids.add(file.getId());
					}
					if (!control.downloadFiles(ids).isEmpty())  {
						lblStatus.setText("Files downloaded successfully.");
					} else {
						lblStatus.setText("Error! Cannot download file.");
					}
				} else {
					lblStatus.setText("Oops! No files selected.");
				}
			}
		});
		GridBagConstraints gbc_btnDownload = new GridBagConstraints();
		gbc_btnDownload.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnDownload.insets = new Insets(0, 0, 5, 0);
		gbc_btnDownload.gridx = 12;
		gbc_btnDownload.gridy = 4;
		frame.getContentPane().add(btnDownload, gbc_btnDownload);
		
		JButton btnRefresh = new JButton("Refresh Locker Contents");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.clear();
				for (MenrvaFile file : control.getFiles()) {
					model.addElement(file);
				}
			}
		});
		GridBagConstraints gbc_btnRefresh = new GridBagConstraints();
		gbc_btnRefresh.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnRefresh.insets = new Insets(0, 0, 5, 0);
		gbc_btnRefresh.gridx = 12;
		gbc_btnRefresh.gridy = 2;
		frame.getContentPane().add(btnRefresh, gbc_btnRefresh);

		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (list.getSelectedValuesList().isEmpty()) {
					lblStatus.setText("Oops! No files are selected.");
					return;
				}
				for (Object item : list.getSelectedValuesList()) {
					MenrvaFile file = (MenrvaFile) item;
					if (!control.removeFile(file.getId())) {
						lblStatus.setText("Error! Could not delete file " + file.getName() + ". Please refresh files and try again.");
						return;
					}
					model.removeElement(file);
				}
				lblStatus.setText("File removed successfully.");
			}
		});
		GridBagConstraints gbc_btnRemove = new GridBagConstraints();
		gbc_btnRemove.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnRemove.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemove.gridx = 12;
		gbc_btnRemove.gridy = 3;
		frame.getContentPane().add(btnRemove, gbc_btnRemove);
		
		JLabel lblEnrolments = new JLabel("Locker Files");
		GridBagConstraints gbc_lblEnrolments = new GridBagConstraints();
		gbc_lblEnrolments.gridwidth = 2;
		gbc_lblEnrolments.anchor = GridBagConstraints.EAST;
		gbc_lblEnrolments.insets = new Insets(0, 0, 5, 5);
		gbc_lblEnrolments.gridx = 1;
		gbc_lblEnrolments.gridy = 3;
		frame.getContentPane().add(lblEnrolments, gbc_lblEnrolments);
		
		JLabel lblStudentId = new JLabel("File");
		GridBagConstraints gbc_lblStudentId = new GridBagConstraints();
		gbc_lblStudentId.anchor = GridBagConstraints.EAST;
		gbc_lblStudentId.gridwidth = 2;
		gbc_lblStudentId.insets = new Insets(0, 0, 5, 5);
		gbc_lblStudentId.gridx = 1;
		gbc_lblStudentId.gridy = 6;
		frame.getContentPane().add(lblStudentId, gbc_lblStudentId);
		
		txtFile = new JTextField();
		GridBagConstraints gbc_txtFile = new GridBagConstraints();
		gbc_txtFile.gridwidth = 8;
		gbc_txtFile.insets = new Insets(0, 0, 5, 5);
		gbc_txtFile.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFile.gridx = 4;
		gbc_txtFile.gridy = 6;
		frame.getContentPane().add(txtFile, gbc_txtFile);
		txtFile.setColumns(10);
		
		JButton btnBrowse = new JButton("Browse");
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.showOpenDialog(null);
				File file = fileChooser.getSelectedFile();
				String fileName = file.getAbsolutePath();
				txtFile.setText(fileName);
			}
		});
		GridBagConstraints gbc_btnBrowse = new GridBagConstraints();
		gbc_btnBrowse.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnBrowse.insets = new Insets(0, 0, 5, 0);
		gbc_btnBrowse.gridx = 12;
		gbc_btnBrowse.gridy = 6;
		frame.getContentPane().add(btnBrowse, gbc_btnBrowse);
		
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 0, 5);
		gbc_btnBack.gridx = 1;
		gbc_btnBack.gridy = 7;
		frame.getContentPane().add(btnBack, gbc_btnBack);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (txtFile.getText() != null) {
					File file = new File(txtFile.getText());
					if (control.saveLockerFile(file, file.getName())) {
						lblStatus.setText("File uploaded successfully.");
						txtFile.setText("");
					} else {
						lblStatus.setText("Error! Could not upload file.");
					}
				} else {
					lblStatus.setText("Please provide a valid file name.");
				}
			}
		});
		GridBagConstraints gbc_btnAdd = new GridBagConstraints();
		gbc_btnAdd.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnAdd.gridx = 12;
		gbc_btnAdd.gridy = 7;
		frame.getContentPane().add(btnAdd, gbc_btnAdd);
	}

}
