package menrva.control;

import java.util.List;

import menrva.DataManager;
import menrva.entities.Course;
import menrva.entities.UserAccount;

public class CreateClassListControl {
	private DataManager dm;
	
	public CreateClassListControl(DataManager dm) {
		this.dm = dm;
	}
	
	public List<Course> getCourses() {
		return dm.getAllCourses();
	}
	
	public List<UserAccount> getRegistrations(String courseId) {
		return dm.getRegistrations(courseId);
	}
	
	public boolean saveRegistration(String studentId, String courseId) {
		return dm.saveRegistration(studentId, courseId);
	}
	
	/**
	 * Verify that a user is allowed to register for a course.
	 * @param userId user ID
	 * @param courseId course ID
	 * @return 0 if user is allowed to register, 1 if user does not exist,
	 * 2 if user is not a student, 3 if user is already registered for the course.
	 */
	public int verifyRegistration(String userId, String courseId) {
		UserAccount user = dm.getUserAccount(userId);
		List<UserAccount> registrations = getRegistrations(courseId);

		if (registrations.isEmpty()) {
			return 0;
		}
		if (user == null) {
			return 1;
		}
		if (!user.getType().equals("Student")) {
			return 2;
		}
		for (UserAccount account : registrations) {
			if (user.toString().equals(account.toString())) {
				return 3;
			}
		}
		return 0;
	}
	
	public boolean deleteRegistration(String studentId, String courseId) {
		return dm.deleteRegistration(studentId, courseId);
	}
}
