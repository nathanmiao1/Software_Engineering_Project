package menrva;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import menrva.ui.CreateAssignmentUI;
import menrva.ui.DownloadAssignmentFileUI;
import menrva.ui.LoginUI;
import menrva.ui.UploadRubricUI;
import menrva.ui.setGradeUI;

public class ProfView {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfView window = new ProfView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ProfView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblWelcomeProfessor = new JLabel("Welcome, Professor!");
		GridBagConstraints gbc_lblWelcomeProfessor = new GridBagConstraints();
		gbc_lblWelcomeProfessor.anchor = GridBagConstraints.WEST;
		gbc_lblWelcomeProfessor.gridwidth = 8;
		gbc_lblWelcomeProfessor.insets = new Insets(0, 0, 5, 5);
		gbc_lblWelcomeProfessor.gridx = 1;
		gbc_lblWelcomeProfessor.gridy = 1;
		frame.getContentPane().add(lblWelcomeProfessor, gbc_lblWelcomeProfessor);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI.openWindow();
				frame.setVisible(false);
				frame.dispose();		
			}
		});
		GridBagConstraints gbc_btnLogOut = new GridBagConstraints();
		gbc_btnLogOut.insets = new Insets(0, 0, 5, 5);
		gbc_btnLogOut.gridx = 9;
		gbc_btnLogOut.gridy = 1;
		frame.getContentPane().add(btnLogOut, gbc_btnLogOut);
		
		JButton btnDownloadAssignmentSubmission = new JButton("Download Assignment Submission");
		btnDownloadAssignmentSubmission.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DownloadAssignmentFileUI.openWindow();
			    frame.setVisible(false);
			    frame.dispose();					
			}
		});
		GridBagConstraints gbc_btnDownloadAssignmentSubmission = new GridBagConstraints();
		gbc_btnDownloadAssignmentSubmission.gridwidth = 3;
		gbc_btnDownloadAssignmentSubmission.insets = new Insets(0, 0, 5, 5);
		gbc_btnDownloadAssignmentSubmission.gridx = 1;
		gbc_btnDownloadAssignmentSubmission.gridy = 2;
		frame.getContentPane().add(btnDownloadAssignmentSubmission, gbc_btnDownloadAssignmentSubmission);
		
		JButton btnUploadRubric = new JButton("Upload Rubric");
		btnUploadRubric.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UploadRubricUI.openWindow();
				frame.setVisible(false);
			    frame.dispose();
			}
		});
		GridBagConstraints gbc_btnUploadRubric = new GridBagConstraints();
		gbc_btnUploadRubric.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnUploadRubric.gridwidth = 3;
		gbc_btnUploadRubric.insets = new Insets(0, 0, 5, 5);
		gbc_btnUploadRubric.gridx = 1;
		gbc_btnUploadRubric.gridy = 4;
		frame.getContentPane().add(btnUploadRubric, gbc_btnUploadRubric);
		
		JButton btnUploadAssignment = new JButton("Create Assignment");
		btnUploadAssignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateAssignmentUI.openWindow();
				frame.setVisible(false);
				frame.dispose();	
			}
		});
		GridBagConstraints gbc_btnUploadAssignment = new GridBagConstraints();
		gbc_btnUploadAssignment.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnUploadAssignment.gridwidth = 3;
		gbc_btnUploadAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_btnUploadAssignment.gridx = 1;
		gbc_btnUploadAssignment.gridy = 5;
		frame.getContentPane().add(btnUploadAssignment, gbc_btnUploadAssignment);	
		gbc_btnUploadAssignment.gridy = 3;
		frame.getContentPane().add(btnUploadAssignment, gbc_btnUploadAssignment);
		
		JButton btnSetGrade = new JButton("Set Grade");
		btnSetGrade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setGradeUI.openWindow();
				frame.setVisible(false);
				frame.dispose();	
			}
		});
		GridBagConstraints gbc_btnSetGrade = new GridBagConstraints();
		gbc_btnSetGrade.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnSetGrade.gridwidth = 3;
		gbc_btnSetGrade.insets = new Insets(0, 0, 0, 5);
		gbc_btnSetGrade.gridx = 1;
		gbc_btnSetGrade.gridy = 5;
		frame.getContentPane().add(btnSetGrade, gbc_btnSetGrade);
    
	}

}
