package menrva.control;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import menrva.DataManager;
import menrva.entities.MenrvaFile;

public class LockerControl {
	private DataManager dm;

	public LockerControl(DataManager dm) {
		this.dm = dm;
	}
	
	public boolean saveLockerFile(File file, String name) {
		return dm.saveLockerFile(file, name, LoginControl.user.getId());
	}
	
	public List<File> downloadFiles(List<Integer> ids) {
		List<File> files = new ArrayList<>();
		for (int id : ids) {
			files.add(dm.retrieveFile(id));
		}
		return files;
	}
	
	public List<MenrvaFile> getFiles() {
		return dm.getLockerFiles(LoginControl.user.getId());
	}
	
	public boolean removeFile(int fileId) {
		return dm.removeLockerFile(fileId);
	}
}
