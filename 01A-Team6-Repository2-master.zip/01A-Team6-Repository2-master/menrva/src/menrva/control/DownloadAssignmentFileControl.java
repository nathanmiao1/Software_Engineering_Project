package menrva.control;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import menrva.DataManager;
import menrva.entities.Assignment;
import menrva.entities.Course;
import menrva.entities.MenrvaFile;
import menrva.entities.UserAccount;

public class DownloadAssignmentFileControl {
	private DataManager dm;

	public DownloadAssignmentFileControl(DataManager dm) {
		this.dm = dm;
	}
	
	public List<Course> getCourses() {
		UserAccount user = LoginControl.user;
		return dm.getCourses(user.getId(), user.getType());
	}
	
	public List<Assignment> getAssignments(String courseId) {
		return dm.getAssignments(courseId);
	}
	
	public boolean downloadFiles(List<Integer> ids) {
		List<File> files = new ArrayList<>();
		for (int id : ids) {
			files.add(dm.retrieveFile(id));
		}
		if (files.size() == ids.size()) {
			return true;
		}
		return false;
	}
	
	public List<MenrvaFile> getAssignmentFiles(Integer assignmentId) {
		return dm.getAssignmentFiles(assignmentId, "Submission");
	}
	
}
