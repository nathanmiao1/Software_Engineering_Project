package menrva.entities;

import java.io.File;

public class MenrvaFile extends File {
	private int id;
	
	public MenrvaFile(String pathname) {
		super(pathname);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String toString() {
		return this.getName();
	}
}
