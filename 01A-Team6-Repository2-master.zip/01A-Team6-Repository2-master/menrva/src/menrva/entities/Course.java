package menrva.entities;

import java.util.ArrayList;
import java.util.List;

public class Course {
	private String id;
	private String name;
	private List<UserAccount> profs;
	private List<UserAccount> tas;
	private String location;
	private String description;
	
	public Course() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<UserAccount> getProfs() {
		return profs;
	}

	public void setProfs(List<UserAccount> profs) {
		this.profs = profs;
	}
	
	public void addProf(UserAccount prof) {
		if (this.profs == null) {
			this.profs = new ArrayList<>();
		}
		this.profs.add(prof);
	}

	public List<UserAccount> getTas() {
		return tas;
	}

	public void setTas(List<UserAccount> tas) {
		this.tas = tas;
	}
	
	public void addTA(UserAccount ta) {
		if (this.tas == null) {
			this.tas = new ArrayList<>();
		}
		this.tas.add(ta);
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString() {
		if (getDescription() != null) {
			return getId() + " : " + getDescription();
		}
		return getId();
	}
	
}
