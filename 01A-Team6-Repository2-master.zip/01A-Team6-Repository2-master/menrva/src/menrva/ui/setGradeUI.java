package menrva.ui;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import menrva.DataManager;
import menrva.ProfView;
import menrva.TAView;
import menrva.control.GradesControl;
import menrva.control.LoginControl;
import menrva.entities.Assignment;
import menrva.entities.Course;

public class setGradeUI {

	private JFrame frame;
	private JTextField studIdTextField;
	private JTextField gradeTextField;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					setGradeUI window = new setGradeUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public setGradeUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		DataManager dm = new DataManager();
		GradesControl control = new GradesControl(dm);
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblStudentId = new JLabel("Student ID");
		GridBagConstraints gbc_lblStudentId = new GridBagConstraints();
		gbc_lblStudentId.anchor = GridBagConstraints.EAST;
		gbc_lblStudentId.insets = new Insets(0, 0, 5, 5);
		gbc_lblStudentId.gridx = 0;
		gbc_lblStudentId.gridy = 2;
		frame.getContentPane().add(lblStudentId, gbc_lblStudentId);
		
		studIdTextField = new JTextField();
		GridBagConstraints gbc_studIdTextField = new GridBagConstraints();
		gbc_studIdTextField.insets = new Insets(0, 0, 5, 0);
		gbc_studIdTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_studIdTextField.gridx = 1;
		gbc_studIdTextField.gridy = 2;
		frame.getContentPane().add(studIdTextField, gbc_studIdTextField);
		studIdTextField.setColumns(10);
		
		JLabel lblCourseId = new JLabel("Course");
		GridBagConstraints gbc_lblCourseId = new GridBagConstraints();
		gbc_lblCourseId.anchor = GridBagConstraints.EAST;
		gbc_lblCourseId.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourseId.gridx = 0;
		gbc_lblCourseId.gridy = 3;
		frame.getContentPane().add(lblCourseId, gbc_lblCourseId);
		
		JComboBox cmbCourse = new JComboBox();
		GridBagConstraints gbc_cmbCourse = new GridBagConstraints();
		gbc_cmbCourse.insets = new Insets(0, 0, 5, 0);
		gbc_cmbCourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbCourse.gridx = 1;
		gbc_cmbCourse.gridy = 3;
		frame.getContentPane().add(cmbCourse, gbc_cmbCourse);
		// add user courses to form
		for (Course course : control.getCourses()) {
			cmbCourse.addItem(course);
		}
		
		JLabel lblGrade = new JLabel("Grade");
		GridBagConstraints gbc_lblGrade = new GridBagConstraints();
		gbc_lblGrade.insets = new Insets(0, 0, 5, 5);
		gbc_lblGrade.anchor = GridBagConstraints.EAST;
		gbc_lblGrade.gridx = 0;
		gbc_lblGrade.gridy = 4;
		frame.getContentPane().add(lblGrade, gbc_lblGrade);
		
		gradeTextField = new JTextField();
		GridBagConstraints gbc_gradeTextField = new GridBagConstraints();
		gbc_gradeTextField.insets = new Insets(0, 0, 5, 0);
		gbc_gradeTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_gradeTextField.gridx = 1;
		gbc_gradeTextField.gridy = 4;
		frame.getContentPane().add(gradeTextField, gbc_gradeTextField);
		gradeTextField.setColumns(10);
		
		JLabel lblWeight = new JLabel("Weight");
		GridBagConstraints gbc_lblWeight = new GridBagConstraints();
		gbc_lblWeight.insets = new Insets(0, 0, 5, 5);
		gbc_lblWeight.anchor = GridBagConstraints.EAST;
		gbc_lblWeight.gridx = 0;
		gbc_lblWeight.gridy = 5;
		frame.getContentPane().add(lblWeight, gbc_lblWeight);
		
		
		
		JTextField weightTextField = new JTextField();
		GridBagConstraints gbc_weightTextField = new GridBagConstraints();
		gbc_weightTextField.insets = new Insets(0, 0, 5, 0);
		gbc_weightTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_weightTextField.gridx = 1;
		gbc_weightTextField.gridy = 5;
		frame.getContentPane().add(weightTextField, gbc_weightTextField);
		weightTextField.setColumns(10);
		
		JComboBox cmbAssignments = new JComboBox();
		GridBagConstraints gbc_cmbAssignments = new GridBagConstraints();
		gbc_cmbAssignments.insets = new Insets(0, 0, 5, 0);
		gbc_cmbAssignments.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbAssignments.gridx = 1;
		gbc_cmbAssignments.gridy = 7;
		frame.getContentPane().add(cmbAssignments, gbc_cmbAssignments);
		
		JButton btnRefreshAssignmentsFor = new JButton("Refresh Assignments for Course");
		btnRefreshAssignmentsFor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Course course = (Course) cmbCourse.getSelectedItem();
				if (course != null) {
					String courseId = course.getId();
					courseId.replace("'", "\\'");
					List<Assignment> assignments = control.getAssignments(courseId);
					cmbAssignments.removeAllItems();
					for (Assignment assignment : assignments) {
						cmbAssignments.addItem(assignment);
					}
				}
			}
		});
		GridBagConstraints gbc_btnRefreshAssignmentsFor = new GridBagConstraints();
		gbc_btnRefreshAssignmentsFor.insets = new Insets(0, 0, 5, 0);
		gbc_btnRefreshAssignmentsFor.gridx = 1;
		gbc_btnRefreshAssignmentsFor.gridy = 6;
		frame.getContentPane().add(btnRefreshAssignmentsFor, gbc_btnRefreshAssignmentsFor);
		
		JLabel lblAssignmentId = new JLabel("Assignment");
		GridBagConstraints gbc_lblAssignmentId = new GridBagConstraints();
		gbc_lblAssignmentId.insets = new Insets(0, 0, 5, 5);
		gbc_lblAssignmentId.anchor = GridBagConstraints.EAST;
		gbc_lblAssignmentId.gridx = 0;
		gbc_lblAssignmentId.gridy = 7;
		frame.getContentPane().add(lblAssignmentId, gbc_lblAssignmentId);
		
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String type = LoginControl.user.getType();
				if (type == "Professor") {
					ProfView.openWindow();
				} else {
					TAView.openWindow();
				}
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 5, 5);
		gbc_btnBack.gridx = 0;
		gbc_btnBack.gridy = 10;
		frame.getContentPane().add(btnBack, gbc_btnBack);
	
		JButton btnSubmit = new JButton("Submit");
		GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
		gbc_btnSubmit.anchor = GridBagConstraints.EAST;
		gbc_btnSubmit.insets = new Insets(0, 0, 5, 0);
		gbc_btnSubmit.gridx = 1;
		gbc_btnSubmit.gridy = 9;
		frame.getContentPane().add(btnSubmit, gbc_btnSubmit);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(studIdTextField.getText().length() == 0 || cmbCourse.getSelectedItem() == null || cmbAssignments.getSelectedItem() == null  || gradeTextField.getText().length() == 0 || weightTextField.getText().length() == 0) {
					JOptionPane.showMessageDialog(btnSubmit, "Please fill all fields", "Failure", 0);
					return;
				}
				
				String studId = studIdTextField.getText();
				Course course = (Course) cmbCourse.getSelectedItem();
				String courseId = course.getId();
				Assignment as = (Assignment) cmbAssignments.getSelectedItem();
				String assgId = Integer.toString(as.getId());
				String gradeString = gradeTextField.getText();
				String weightString = weightTextField.getText();
				
				//send parameters to the setGrade UI
				double grade = Double.parseDouble(gradeString);
				int weight = Integer.parseInt(weightString);
				int ret = control.insertGrade(studId, assgId, grade, courseId, weight);
				if(ret == 1)
					JOptionPane.showMessageDialog(btnSubmit, control.getMessage(), "Failure", ret);
				else
					JOptionPane.showMessageDialog(btnSubmit, control.getMessage(), "Success", ret);
			}
		});
	}

}
