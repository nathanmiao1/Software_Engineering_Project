package menrva.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.SwingConstants;

import menrva.DataManager;
import menrva.ProfView;
import menrva.control.CreateAssignmentControl;
import menrva.util.*;
import menrva.entities.Course;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CreateAssignmentUI {

	private JFrame frame;
	private JTextField AssignmentName;
	private JLabel lblCourse;
	private JComboBox courseList;
	private JButton btnRefresh;
	private JButton btnMenu;
	private JButton btnCreateAssignment;
	private JLabel lblTitleError;
	private JLabel lblCourseError;
	private JLabel lblConfirmation;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateAssignmentUI window = new CreateAssignmentUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CreateAssignmentUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		CreateAssignmentControl control = new CreateAssignmentControl(new DataManager());
		
		
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 230);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{21, 0, 0, 0, 41, -25, 51, 117, 0, 0, 24, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblAssignmentTitle = new JLabel("Assignment Title:");
		GridBagConstraints gbc_lblAssignmentTitle = new GridBagConstraints();
		gbc_lblAssignmentTitle.gridwidth = 4;
		gbc_lblAssignmentTitle.insets = new Insets(0, 0, 5, 5);
		gbc_lblAssignmentTitle.gridx = 1;
		gbc_lblAssignmentTitle.gridy = 2;
		frame.getContentPane().add(lblAssignmentTitle, gbc_lblAssignmentTitle);
		
		AssignmentName = new JTextField();
		GridBagConstraints gbc_AssignmentName = new GridBagConstraints();
		gbc_AssignmentName.gridwidth = 4;
		gbc_AssignmentName.insets = new Insets(0, 0, 5, 5);
		gbc_AssignmentName.fill = GridBagConstraints.HORIZONTAL;
		gbc_AssignmentName.gridx = 6;
		gbc_AssignmentName.gridy = 2;
		frame.getContentPane().add(AssignmentName, gbc_AssignmentName);
		AssignmentName.setColumns(10);
		
		lblTitleError = new JLabel("");
		lblTitleError.setForeground(Color.RED);
		GridBagConstraints gbc_lblTitleError = new GridBagConstraints();
		gbc_lblTitleError.gridwidth = 2;
		gbc_lblTitleError.insets = new Insets(0, 0, 5, 5);
		gbc_lblTitleError.gridx = 6;
		gbc_lblTitleError.gridy = 3;
		frame.getContentPane().add(lblTitleError, gbc_lblTitleError);
		
		lblCourse = new JLabel("Course:");
		GridBagConstraints gbc_lblCourse = new GridBagConstraints();
		gbc_lblCourse.gridwidth = 4;
		gbc_lblCourse.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourse.gridx = 1;
		gbc_lblCourse.gridy = 4;
		frame.getContentPane().add(lblCourse, gbc_lblCourse);
		
		courseList = new JComboBox();
		GridBagConstraints gbc_courseList = new GridBagConstraints();
		gbc_courseList.gridwidth = 3;
		gbc_courseList.insets = new Insets(0, 0, 5, 5);
		gbc_courseList.fill = GridBagConstraints.HORIZONTAL;
		gbc_courseList.gridx = 6;
		gbc_courseList.gridy = 4;
		frame.getContentPane().add(courseList, gbc_courseList);
		
		//add courses to drop-down box
		for (Course course : control.getCourses()) {
			courseList.addItem(course.getId());
		}
		
		btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				courseList.removeAllItems();
				for (Course course : control.getCourses()) {
					courseList.addItem(course.getId());
				}
			}
		});
		GridBagConstraints gbc_btnRefresh = new GridBagConstraints();
		gbc_btnRefresh.insets = new Insets(0, 0, 5, 5);
		gbc_btnRefresh.gridx = 9;
		gbc_btnRefresh.gridy = 4;
		frame.getContentPane().add(btnRefresh, gbc_btnRefresh);
		
		lblCourseError = new JLabel("");
		lblCourseError.setHorizontalAlignment(SwingConstants.LEFT);
		lblCourseError.setForeground(Color.RED);
		GridBagConstraints gbc_lblCourseError = new GridBagConstraints();
		gbc_lblCourseError.gridwidth = 2;
		gbc_lblCourseError.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourseError.gridx = 6;
		gbc_lblCourseError.gridy = 5;
		frame.getContentPane().add(lblCourseError, gbc_lblCourseError);
		
		lblConfirmation = new JLabel("");
		GridBagConstraints gbc_lblConfirmation = new GridBagConstraints();
		gbc_lblConfirmation.gridwidth = 5;
		gbc_lblConfirmation.insets = new Insets(0, 0, 5, 5);
		gbc_lblConfirmation.gridx = 4;
		gbc_lblConfirmation.gridy = 6;
		frame.getContentPane().add(lblConfirmation, gbc_lblConfirmation);
		
		btnCreateAssignment = new JButton("Create Assignment");
		btnCreateAssignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String assignName = AssignmentName.getText();
				boolean check = true;
				if (assignName.isEmpty()) {
					check = false;
					lblTitleError.setText("*Enter assignment name.");
				} else {lblTitleError.setText("");}
				if (courseList.getSelectedItem() == null) {
					check = false;
					lblCourseError.setText("*No courses available.");
				} else {lblCourseError.setText("");}
				
				if (check) {
					String courseId = courseList.getSelectedItem().toString();
					if (control.saveAssignment(assignName, courseId)) {
						lblConfirmation.setText("Assignment created");
						AssignmentName.setText("");
					} else {
						lblConfirmation.setText("ERROR: Assignment not created");
					}
				} else {lblConfirmation.setText("");}
			}
		});
		GridBagConstraints gbc_btnCreateAssignment = new GridBagConstraints();
		gbc_btnCreateAssignment.gridwidth = 3;
		gbc_btnCreateAssignment.insets = new Insets(0, 0, 5, 5);
		gbc_btnCreateAssignment.gridx = 7;
		gbc_btnCreateAssignment.gridy = 7;
		frame.getContentPane().add(btnCreateAssignment, gbc_btnCreateAssignment);
		
		btnMenu = new JButton("Return to Menu");
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfView.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		GridBagConstraints gbc_btnMenu = new GridBagConstraints();
		gbc_btnMenu.anchor = GridBagConstraints.WEST;
		gbc_btnMenu.gridwidth = 6;
		gbc_btnMenu.insets = new Insets(0, 0, 0, 5);
		gbc_btnMenu.gridx = 1;
		gbc_btnMenu.gridy = 8;
		frame.getContentPane().add(btnMenu, gbc_btnMenu);
	}

}
