package menrva.entities;

public class Rubric {
	private Course course;
	private String id;
	private MenrvaFile file;
	
	public Rubric() {}
	
	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public MenrvaFile getFile() {
		return file;
	}

	public void setFile(MenrvaFile file) {
		this.file = file;
	}

	public String toString() {
		return file.getName();
	}
}