package menrva.control;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import menrva.DataManager;
import menrva.entities.Assignment;
import menrva.entities.Course;
import menrva.entities.MenrvaFile;
import menrva.entities.Rubric;
import menrva.entities.UserAccount;

public class DownloadRubricControl {
	private DataManager dm;

	public DownloadRubricControl(DataManager dm) {
		this.dm = dm;
	}
	
	public boolean downloadFiles(List<Integer> ids) {
		List<File> files = new ArrayList<>();
		for (int id : ids) {
			files.add(dm.retrieveFile(id));
		}
		if (files.size() == ids.size()) {
			return true;
		}
		return false;
	}
	
	public List<Course> getCourses() {
		UserAccount user = LoginControl.user;
		return dm.getCourses(user.getId(), user.getType());
	}
	
	public List<Rubric> getRubrics(String courseId) {
		return dm.getRubrics(courseId);
	}
}