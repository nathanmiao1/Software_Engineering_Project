package menrva.ui;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

import menrva.AdminView;
import menrva.DataManager;
import menrva.control.CreateClassListControl;
import menrva.entities.Course;
import menrva.entities.UserAccount;

public class CreateClassListUI {

	private JFrame frame;
	private JTextField txtStudent;
	private DefaultListModel<Object> model;

	/**
	 * Launch the application.
	 */
	public static void openWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateClassListUI window = new CreateClassListUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the application.
	 */
	public CreateClassListUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		CreateClassListControl control = new CreateClassListControl(new DataManager());
		model = new DefaultListModel<>();
		frame = new JFrame();
		frame.setBounds(100, 100, 483, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminView.openWindow();
				frame.setVisible(false);
				frame.dispose();
			}
		});
		
		JLabel lblCourse = new JLabel("Course");
		GridBagConstraints gbc_lblCourse = new GridBagConstraints();
		gbc_lblCourse.anchor = GridBagConstraints.EAST;
		gbc_lblCourse.gridwidth = 2;
		gbc_lblCourse.insets = new Insets(0, 0, 5, 5);
		gbc_lblCourse.gridx = 1;
		gbc_lblCourse.gridy = 2;
		frame.getContentPane().add(lblCourse, gbc_lblCourse);
		
		JLabel lblStatus = new JLabel("");
		GridBagConstraints gbc_lblStatus = new GridBagConstraints();
		gbc_lblStatus.gridwidth = 9;
		gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
		gbc_lblStatus.gridx = 3;
		gbc_lblStatus.gridy = 5;
		frame.getContentPane().add(lblStatus, gbc_lblStatus);
		
		JComboBox cmbCourse = new JComboBox();
		
		GridBagConstraints gbc_cmbCourse = new GridBagConstraints();
		gbc_cmbCourse.gridwidth = 8;
		gbc_cmbCourse.insets = new Insets(0, 0, 5, 5);
		gbc_cmbCourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbCourse.gridx = 3;
		gbc_cmbCourse.gridy = 2;
		frame.getContentPane().add(cmbCourse, gbc_cmbCourse);
		cmbCourse.setSelectedItem(null);

		// add all courses to form
		for (Course course : control.getCourses()) {
			cmbCourse.addItem(course);
		}
		
		JButton btnSelect = new JButton("Refresh Enrolments");
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.clear();
				for (UserAccount student : control.getRegistrations(((Course) cmbCourse.getSelectedItem()).getId())) {
					model.addElement(student);
				}
			}
		});
		GridBagConstraints gbc_btnSelect = new GridBagConstraints();
		gbc_btnSelect.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnSelect.insets = new Insets(0, 0, 5, 0);
		gbc_btnSelect.gridx = 11;
		gbc_btnSelect.gridy = 2;
		frame.getContentPane().add(btnSelect, gbc_btnSelect);
		
		JList list = new JList(model);
		GridBagConstraints gbc_list = new GridBagConstraints();
		gbc_list.gridwidth = 8;
		gbc_list.insets = new Insets(0, 0, 5, 5);
		gbc_list.fill = GridBagConstraints.BOTH;
		gbc_list.gridx = 3;
		gbc_list.gridy = 3;
		frame.getContentPane().add(list, gbc_list);

		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (list.getSelectedValuesList().isEmpty()) {
					lblStatus.setText("Oops! No students are selected.");
					return;
				}
				for (Object item : list.getSelectedValuesList()) {
					UserAccount student = (UserAccount) item;
					if (!control.deleteRegistration(student.getId(), ((Course) cmbCourse.getSelectedItem()).getId())) {
						lblStatus.setText("Error! Could not delete student " + student + ". Please refresh enrolments and try again.");
						return;
					}
					model.removeElement(student);
				}
				lblStatus.setText("Student unregistered successfully.");
			}
		});
		GridBagConstraints gbc_btnRemove = new GridBagConstraints();
		gbc_btnRemove.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnRemove.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemove.gridx = 11;
		gbc_btnRemove.gridy = 3;
		frame.getContentPane().add(btnRemove, gbc_btnRemove);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (txtStudent.getText() != null) {
					String userId = txtStudent.getText().replace("'", "\\'");
					String courseId = ((Course) cmbCourse.getSelectedItem()).getId();
					
					
					switch (control.verifyRegistration(userId, courseId)) {
						case 0:
							if (control.saveRegistration(txtStudent.getText(), ((Course) cmbCourse.getSelectedItem()).getId())) {
								lblStatus.setText("Student registered for course successfully.");
							} else {
								lblStatus.setText("Error! Cannot register student for course.");
							}
							break;
						case 1:
							lblStatus.setText("Please provide a valid student id.");
							break;
						case 2:
							lblStatus.setText("Please provide a valid student id.");
							break;
						case 3:
							lblStatus.setText("Oops! This student is already registered for this course.");
							break;
					}
				} else {
					lblStatus.setText("Please provide a valid student id.");
				}
			}
		});
		GridBagConstraints gbc_btnAdd = new GridBagConstraints();
		gbc_btnAdd.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnAdd.insets = new Insets(0, 0, 5, 0);
		gbc_btnAdd.gridx = 11;
		gbc_btnAdd.gridy = 4;
		frame.getContentPane().add(btnAdd, gbc_btnAdd);
		
		JLabel lblEnrolments = new JLabel("Enrolments");
		GridBagConstraints gbc_lblEnrolments = new GridBagConstraints();
		gbc_lblEnrolments.gridwidth = 2;
		gbc_lblEnrolments.anchor = GridBagConstraints.EAST;
		gbc_lblEnrolments.insets = new Insets(0, 0, 5, 5);
		gbc_lblEnrolments.gridx = 1;
		gbc_lblEnrolments.gridy = 3;
		frame.getContentPane().add(lblEnrolments, gbc_lblEnrolments);
		
		JLabel lblStudentId = new JLabel("Student ID");
		GridBagConstraints gbc_lblStudentId = new GridBagConstraints();
		gbc_lblStudentId.anchor = GridBagConstraints.EAST;
		gbc_lblStudentId.gridwidth = 2;
		gbc_lblStudentId.insets = new Insets(0, 0, 5, 5);
		gbc_lblStudentId.gridx = 1;
		gbc_lblStudentId.gridy = 4;
		frame.getContentPane().add(lblStudentId, gbc_lblStudentId);
		
		txtStudent = new JTextField();
		GridBagConstraints gbc_txtStudent = new GridBagConstraints();
		gbc_txtStudent.gridwidth = 8;
		gbc_txtStudent.insets = new Insets(0, 0, 5, 5);
		gbc_txtStudent.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtStudent.gridx = 3;
		gbc_txtStudent.gridy = 4;
		frame.getContentPane().add(txtStudent, gbc_txtStudent);
		txtStudent.setColumns(10);
		
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 0, 5);
		gbc_btnBack.gridx = 1;
		gbc_btnBack.gridy = 7;
		frame.getContentPane().add(btnBack, gbc_btnBack);
	}

}
